package controlstru;


import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/** This is a Ex1_Peddi class
 *
 * @author s554220
 */
public class Ex1_Peddi {
    
    public static void main(String[] args) {
        
        double rate = 0;
        int o=0;
        final double TAX_RATE = 0.08;
      System.out.println(" ***** Welcome to Zombie's  & Gombie ***** ");
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("What is your  name?");
        
        String s = sc.nextLine();
        
       
         System.out.print("Pizza Size (inches)  Cost\n");
         System.out.println("    10            $10.99\n" +"    12            $12.99\n" +"    14            $14.99\n" +"    16            $16.99");
        System.out.println("What size of pizza would you like?");
         System.out.println("10\", 12\", 14\", or 16\" (Enter one size only): ");
        int a = sc.nextInt();
        
        
        switch(a){
            case 10: rate=10.99;
                        break;
            case 12: rate=12.99;
                        break;
            case 14: rate=14.99;
                        break;
            case 16: rate=16.99;
                        break;
            default : System.out.println("Enter a valid input");
                     break;
        }
        
         System.out.println("Are you a student? (Y/N):");
        
         String b = sc.next();
        
         if (b.equalsIgnoreCase("y")){
            o = 2;
            System.out.println("You are eligible for a $2.00 discount");
          }
         else{
            System.out.println("Not applicable for student discount");
         }
        
        
        System.out.println("What type of crust would you like to have? ");
        System.out.print("(T) Thin Crust, (O) Original Crust , or (S) Skillet Crust(enter T, O, or S):");
        String t = sc.next().toLowerCase();
        
      switch(t) 
         {
            case "t" :
            System.out.println("All pizzas come with cheese.\n" +"Additional toppings are $0.75 each, choose from:");
        System.out.println("Would you like to add beef? (Y/N): ");
        String e = sc.next();
        String tp="Cheese, ";
        if (e.equalsIgnoreCase("y")) 
        {
             rate +=0.75; tp+="Beef, ";
        }
        System.out.println("Would you like to add Tomatoes? (Y/N): ");
        String q = sc.next();
        if (q.equalsIgnoreCase("y")) 
        {
            rate+=0.75; tp+="Tomatoes, ";
        }
        System.out.println("Would you like to add Black Olives? (Y/N): ");
        String v = sc.next();
        if (v.equalsIgnoreCase("y")) 
        {
            rate+=0.75; tp+="Black Olives, ";
        }
        System.out.println("Would you like to add Mushrooms (Y/N): ");
        String x = sc.next();
        if (x.equalsIgnoreCase("y"))
        {
            rate+=0.75; tp+="Mushrooms, ";
        }
        System.out.println("Would you like to add Green Peppers (Y/N): ");
        String greenPeppers = sc.next();
        if (greenPeppers.equalsIgnoreCase("y"))
        {
            rate+=0.75; tp+="Green Peppers  ";
        }
        rate-=o;
        
        double k = Math.round(rate* TAX_RATE*100)/100.0;
        double z = rate+k;
        System.out.println("-> Your order is as follows: ");
        System.out.println("->"+a+" inch pizza");
         System.out.println("-> Thin Crust");
        System.out.println("->"+tp);
        System.out.println("The cost of your order is: $"+rate);
        System.out.println("The tax is: $"+k);
        System.out.println("The total due is:  $"+z);
        System.out.println("-> Enjoy your Pizza and your order will be ready  in 20 minutes.");
    
        break;
        
          
   
            case "o" :
            System.out.println("All pizzas come with cheese.\n" +"Additional toppings are $0.75 each, choose from:");
        System.out.println("Would you like to add beef? (Y/N): ");
        String w = sc.next();
        String y="Cheese, ";
        if (w.equalsIgnoreCase("y")) 
        {
             rate +=0.75; y+="Beef, ";
        }
        System.out.println("Would you like to add Tomatoes? (Y/N): ");
        String u = sc.next();
        if (u.equalsIgnoreCase("y")) 
        {
            rate+=0.75; y+="Tomatoes, ";
        }
        System.out.println("Would you like to add Black Olives? (Y/N): ");
        String bl = sc.next();
        if (bl.equalsIgnoreCase("y")) 
        {
            rate+=0.75; y+="Black Olives, ";
        }
        System.out.println("Would you like to add Mushrooms (Y/N): ");
        String d = sc.next();
        if (d.equalsIgnoreCase("y"))
        {
            rate+=0.75; y+="Mushrooms, ";
        }
        System.out.println("Would you like to add Green Peppers (Y/N): ");
        String f = sc.next();
        if (f.equalsIgnoreCase("y"))
        {
            rate+=0.75; y+="Green Peppers  ";
        }
        rate-=o;
      
        double zz = Math.round(rate* TAX_RATE*100)/100.0;
        double vv = rate+zz;
        System.out.println("-> Your order is as follows: ");
        System.out.println("->"+a+" inch pizza");
         System.out.println("-> Thin Crust");
        System.out.println("->"+y);
        System.out.println("The cost of your order is: $"+rate);
        System.out.println("The tax is: $"+zz);
        System.out.println("The total due is:  $"+vv);
        System.out.println("-> Enjoy your Pizza and your order will be ready  in 20 minutes.");
    
        break;
        
          case "s" :
            System.out.println("All pizzas come with cheese.\n" +"Additional toppings are $0.75 each, choose from:");
        System.out.println("Would you like to add beef? (Y/N): ");
        String ee = sc.next();
        String ttp="Cheese, ";
        if (ee.equalsIgnoreCase("y")) 
        {
             rate +=0.75; ttp+="Beef, ";
        }
        System.out.println("Would you like to add Tomatoes? (Y/N): ");
        String qg = sc.next();
        if (qg.equalsIgnoreCase("y")) 
        {
            rate+=0.75; ttp+="Tomatoes, ";
        }
        System.out.println("Would you like to add Black Olives? (Y/N): ");
        String vvv = sc.next();
        if (vvv.equalsIgnoreCase("y")) 
        {
            rate+=0.75; ttp+="Black Olives, ";
        }
        System.out.println("Would you like to add Mushrooms (Y/N): ");
        String xx = sc.next();
        if (xx.equalsIgnoreCase("y"))
        {
            rate+=0.75; ttp+="Mushrooms, ";
        }
        System.out.println("Would you like to add Green Peppers (Y/N): ");
        String gp = sc.next();
        if (gp.equalsIgnoreCase("y"))
        {
            rate+=0.75; ttp+="Green Peppers  ";
        }
        rate-=o;
        
        double kkl = Math.round(rate*TAX_RATE*100)/100.0;
        double zzz = rate+kkl;
        System.out.println("-> Your order is as follows: ");
        System.out.println("->"+a+" inch pizza");
         System.out.println("-> Thin Crust");
        System.out.println("->"+ttp);
        System.out.println("The cost of your order is: $"+rate);
        System.out.println("The tax is: $"+kkl);
        System.out.println("The total due is:  $"+zzz);
        System.out.println("-> Enjoy your Pizza and your order will be ready  in 20 minutes.");
    
        break;
        
        
        
        
        
      }}
        
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
