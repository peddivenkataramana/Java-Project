package controlstru;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

 

/**
 *This is a Ex2_Peddi
 * This class contains reading data from file and writing into other file
 * @author s554220
 */
public class Ex2_Peddi {
    
    
    public static void main(String[] args) throws FileNotFoundException {
        
         int odd=0;
        int even=0;
        Scanner sc = new Scanner(new File("lab4datafile.txt"));
        PrintWriter m = new PrintWriter(new File("even.txt"));
        PrintWriter n = new PrintWriter(new File("odd.txt"));
         
     while(sc.hasNext()){
          
         int u=sc.nextInt();
         
        if(u%2==0){
          m.println(u);
           even++;
         }
         else
          {
          n.println(u);
        odd++;
          }
     
      
     }
        m.close();
       n.close();
      sc.close();
     System.out.println("Number  of  even  numbers : "+even);
     System.out.println("Number  of  odd  numbers: "+odd);
        System.out.println("Number of numbers divisible by 7 :"+isDivisibleBy7());
   
    }
    
    public static int isDivisibleBy7() throws FileNotFoundException{
      Scanner scan = new Scanner(new File("lab4datafile.txt"));
      PrintWriter pm = new PrintWriter(new File("seven.txt"));
      int rep =0;
       while(scan.hasNext())
       {
        int ss=scan.nextInt();
         int d=ss%10;
         d= d*2;
         int b=ss/10;
         b = b-d;
         if(b%7==0){
             pm.println(ss);
             rep++;
          }}
    scan.close();
        pm.close();
        return rep;
      }
}
      
        
     
        
        
        
        
        
        
        
        
        
     
      
    
    
