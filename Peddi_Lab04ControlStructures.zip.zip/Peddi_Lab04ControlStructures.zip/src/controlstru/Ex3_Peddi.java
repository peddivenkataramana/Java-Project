package controlstru;


import java.util.Random;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *This is Ex3_Peddi class
 * 
 * @author s554220
 */
public class Ex3_Peddi {
    
     /**
      * This is a throwDice1 method
      * @return l
      */
        
        public static int throwDice1(){
           
             int min = 6;
      int max = 15;
            int l = (int)Math.floor(Math.random()*(max-min+1)+min);
            return l;
           }
        /**
         * This is  throwDice2 method 
         * @return l1
         */
        public static int throwDice2(){
          
              int min = 1;
      int max = 6;
           int l1 = (int)Math.floor(Math.random()*(max-min+1)+min);
           return l1;
        }
        /**
         * This is a sumDice1Dice2 method
         * @param p
         * @param k
         * @return a
         */
        public static int sumDice1Dice2(int p,int k){
            
            System.out.println("Dice1:"+p);
            System.out.println("Dice2:"+k);
            int a =p+k;
            System.out.println("The sum of Dice1 and Dice 2 is: "+a);
            return a;
        }
        
        
        
        
        
         public static void main(String[] args) {
       
 
        int sumation = sumDice1Dice2(throwDice1(),throwDice2());
        if (sumation<=10){
           
        
          int sum=2*sumation;
          double total=0.10*sum;
            System.out.println("Pay a fee: 0.10*"+sum+"=$"+total); 
        }
        else
          System.out.println("Free passage");
        
    }
    
}
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    
    
    
    
    
    
    

