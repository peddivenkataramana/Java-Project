/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Class: 44542-05 Object Oriented Programming
 * @author Venkataramana Peddi 
 * Description: Making sure everything works
 * Due:10/30/22 
 * I pledge that I have completed the programming assignment independently. 
 * I have not copied the code from a student or any source. 
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class AccountNGTest {

    static Account a;
    static Customer b;
    static Transaction c;
    static ArrayList<Transaction> d = new ArrayList<Transaction>();

    public AccountNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
        DateTimeFormatter d = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String e = "2022-09-04 11:30:03";
        LocalDateTime f = LocalDateTime.parse(e, d);
        c = new Transaction("DEPOSIT", 1000.00, f);
        b = new Customer("05/05/2000", "Venkataramana", "Peddi");
        a = new Account(1111111111l, b, true);
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }

    /**
     * Test of getAccountNumber method, of class Account.
     */
    @Test
    public void testGetAccountNumber() {
        System.out.println("getAccountNumber");
        long expResult = 1111111111l;
        long result = a.getAccountNumber();
        assertEquals(result, expResult);
    }

    public void testGetAccountNumberfail() {
        System.out.println("getAccountNumber");
        long expResult = 94566671l;
        long result = a.getAccountNumber();
        assertNotEquals(result, expResult);
    }

    /**
     * Test of getCustomer method, of class Account.
     */
    @Test
    public void testGetCustomer() {
        System.out.println("getCustomer");
        Customer expResult = b;
        Customer result = a.getCustomer();
        assertEquals(result, expResult);
    }

    /**
     * Test of testGetCustomerfail method, of class Account.
     */
    public void testGetCustomerfail() {
        System.out.println("getCustomer");
        Customer expResult = b;
        Customer result = a.getCustomer();
        assertNotEquals(result, expResult);
    }

    /**
     * Test of getBalance method, of class Account.
     */
    @Test
    public void testGetBalance() {
        System.out.println("getBalance");
        double expResult = 11.0;
        double result = a.getBalance();
        assertEquals(result, expResult, 11.0);
    }

    /**
     * Test of testGetBalancefail method, of class Account.
     */
    public void testGetBalancefail() {
        System.out.println("getBalance");
        double expResult = 11.0;
        double result = a.getBalance();
        assertNotEquals(result, expResult);
    }

    /**
     * Test of getTransactions method, of class Account.
     */
    @Test
    public void testGetTransactions() {
        System.out.println("getTransactions");
        ArrayList expResult = d;
        ArrayList result = a.getTransactions();
        assertEquals(result, expResult);
    }

    /**
     * Test of isHasLimitedWithdrawals method, of class Account.
     */
    @Test
    public void testIsHasLimitedWithdrawals() {
        System.out.println("isHasLimitedWithdrawals");
        boolean expResult = true;
        boolean result = a.isHasLimitedWithdrawals();
        assertEquals(result, expResult);
    }

    /**
     * Test of testIsHasLimitedWithdrawalsfail method, of class Account.
     */
    public void testIsHasLimitedWithdrawalsfail() {
        System.out.println("isHasLimitedWithdrawals");
        boolean expResult = false;
        boolean result = a.isHasLimitedWithdrawals();
        assertNotEquals(result, expResult);
    }

    /**
     * Test of getSAVING_INTEREST method, of class Account.
     */
    @Test
    public void testGetSAVING_INTEREST() {
        System.out.println("getSAVING_INTEREST");
        double expResult = 7.2;
        double result = a.getSAVING_INTEREST();
        assertEquals(result, expResult, 0.0);
    }

    /**
     * Test of testGetSAVING_INTERESTfail method, of class Account.
     */
    public void testGetSAVING_INTERESTfail() {
        System.out.println("getSAVING_INTEREST");
        double expResult = 12.8;
        double result = a.getSAVING_INTEREST();
        assertNotEquals(result, expResult);
    }

    /**
     * Test of getNoofWithdrawals method, of class Account.
     */
    @Test
    public void testGetNoofWithdrawals() {
        System.out.println("getNoofWithdrawals");
        int expResult = 0;
        int result = a.getNoofWithdrawals();
        assertEquals(result, expResult);
    }

    /**
     * Test of testGetNoofWithdrawalsFail method, of class Account.
     */
    public void testGetNoofWithdrawalsFail() {
        System.out.println("getNoofWithdrawals");
        int expResult = 6;
        int result = a.getNoofWithdrawals();
        assertNotEquals(result, expResult);
    }

    /**
     * Test of makeTransaction method, of class Account.
     */
    @Test
    public void testMakeTransaction() {
        System.out.println("makeTransaction");
        String expResult = "Transaction Successful";
        String result = a.makeTransaction(c);
        System.out.println(d);
        assertEquals(result, expResult);
    }

    /**
     * Test of testMakeTransactionFail method, of class Account.
     */
    @Test
    public void testMakeTransactionFail() {
        System.out.println("makeTransaction");
        String expResult = "Transaction Failure";
        String result = a.makeTransaction(c);
        System.out.println(d);
        assertNotEquals(result, expResult);
    }

}
