/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.time.LocalDateTime;
import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Class: 44542-05 Object Oriented Programming
 * @author Venkataramana Peddi 
 * Description: Making sure everything works
 * Due:10/30/22 
 * I pledge that I have completed the programming assignment independently. 
 * I have not copied the code from a student or any source. 
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class TransactionNGTest {

    static Transaction a;

    public TransactionNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
        a = new Transaction("WITHDRAW", 200.0, LocalDateTime.MIN);
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
        a = null;
    }

    /**
     * Test of testGetAmount method, of class Transaction.
     */
    @Test
    public void testGetAmount() {
        System.out.println("getAmount");
        double expAmount = 200.0;
        double amount = a.getAmount();
        assertEquals(expAmount, amount);
    }

    /**
     * Test of testGetAmount method, of class Transaction.
     */
    @Test
    public void testGetAmountFail() {
        System.out.println("getAmount");
        double expAmount = 1967.0;
        double amount = a.getAmount();
        assertEquals(expAmount, amount);
    }

    /**
     * Test of setAmount method, of class Transaction.
     */
    @Test
    public void testSetAmount() {
        double amount = 200.0;
        a.setAmount(200.0);
        assertEquals(amount, a.getAmount());
    }

    /**
     * Test of testSetAmountFail method, of class Transaction.
     */
    @Test
    public void testSetAmountFail() {
        double amount = 201.0;
        a.setAmount(201.0);

        assertEquals(201, a.getAmount());
    }

    /**
     * Test of testGetDateTime method, of class Transaction.
     */
    @Test
    public void testGetDateTime() {
        LocalDateTime localDateTime = a.getTransactionTime();
        assertEquals(LocalDateTime.MIN, localDateTime);
    }

    /**
     * Test of testGetDateTimeFail method, of class Transaction.
     */
    @Test
    public void testGetDateTimeFail() {
        LocalDateTime localDateTime = a.getTransactionTime();
        assertEquals(LocalDateTime.MAX, localDateTime);
    }

    /**
     * Test of setDateTime method, of class Transaction.
     */
    @Test
    public void testSetDateTime() {
        a.setTransactionTime(LocalDateTime.MIN);
        assertEquals(LocalDateTime.MIN, a.getTransactionTime());
    }

    /**
     * Test of testSetDateTimeFail method, of class Transaction.
     */
    @Test
    public void testSetDateTimeFail() {
        a.setTransactionTime(LocalDateTime.MIN);
        assertEquals(LocalDateTime.MAX, a.getTransactionTime());
    }

    /**
     * Test of getTransactionType method, of class Transaction.
     */
    @Test
    public void testGetTransactionType() {
        String actual = a.getTransactionType();
        String expected = "WITHDRAW";
        assertEquals(expected, actual);
    }

    /**
     * Test of testGetTransactionTypeFail method, of class Transaction.
     */
    @Test
    public void testGetTransactionTypeFail() {
        String actual = a.getTransactionType();
        String expected = "DEPOSIT";
        assertEquals(expected, actual);
    }

    /**
     * Test of setTransactionType method, of class Transaction.
     */
    @Test
    public void testSetTransactionType() {
        System.out.println("setTransactionType");
        String transationType = "DEPOSIT";
        a.setTransactionType(transationType);
        assertEquals(transationType, a.getTransactionType());
    }

    /**
     * Test of testSetTransactionTypeFail method, of class Transaction.
     */
    @Test
    public void testSetTransactionTypeFail() {
        System.out.println("setTransactionType");
        String transationType = "WITHDRAW";
        a.setTransactionType(transationType);
        assertEquals("DEPOSIT", a.getTransactionType());
    }

    /**
     * Test of getAdditionalCharges method, of class Transaction.
     */
    @Test
    public void testGetAdditionalCharges() {
        System.out.println("getAdditionalCharges");
        double expected = 33.00;

        a.setAdditionalCharges(33.00);
        double actual = a.getAdditionalCharges();
        assertEquals(actual, expected);
    }

    /**
     * Test of SetAdditionalCharges method, of class Transaction.
     */
    @Test
    public void testSetAdditionalCharges() {
        System.out.println("setAdditionalCharges");
        double additionalCharges = 200.0;

        a.setAdditionalCharges(additionalCharges);
        assertEquals(a.getAdditionalCharges(), additionalCharges);
    }

    /**
     * Test of testSetAdditionalChargesFail method, of class Transaction.
     */
    @Test
    public void testSetAdditionalChargesFail() {
        System.out.println("setAdditionalCharges");
        double additionalCharges = 200.0;

        a.setAdditionalCharges(additionalCharges);
        assertEquals(a.getAdditionalCharges(), 222.00);
    }

    /**
     * Test of getStatus method, of class Transaction.
     */
    @Test
    public void testGetStatus() {
        System.out.println("getStatus");
        String status = "Failed";
        a.setStatus(status);
        String result = a.getStatus();
        assertEquals(result, status);
    }

    /**
     * Test of testGetStatusFail method, of class Transaction.
     */
    @Test
    public void testGetStatusFail() {
        System.out.println("getStatus");
        String status = "SUCCESS";
        a.setStatus(status);
        String result = a.getStatus();
        assertEquals("FAILURE", status);
    }

    /**
     * Test of setStatus method, of class Transaction.
     */
    @Test
    public void testSetStatus() {
        System.out.println("setStatus");
        String status = "SUCCESS";
        a.setStatus(status);
        String result = a.getStatus();
        assertEquals(result, status);
    }

    /**
     * Test of testSetStatusFail method, of class Transaction.
     */
    @Test
    public void testSetStatusFail() {
        System.out.println("setStatus");
        String status = "FAILURE";
        a.setStatus(status);
        String result = a.getStatus();
        assertEquals("SUCCESS", status);
    }

    /**
     * Test of toString method, of class Transaction.
     */
    // @Test
    public void testToString() {
        System.out.println("toString");
        a.setTransactionType("WITHDRAW");
        a.setAdditionalCharges(200.00);
        a.setAmount(200.0);
        a.setStatus("FAILURE");
        a.setTransactionTime(LocalDateTime.MIN);
        String expResult = "WITHDRAW             -999999999-01-01T00:00      200.00          "
                + "228.00                     FAILURE";
        assertEquals(a.toString(), expResult);
    }

}
