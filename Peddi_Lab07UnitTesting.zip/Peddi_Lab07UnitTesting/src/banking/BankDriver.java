/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Class: 44542-05 Object Oriented Programming
 * @author Venkataramana Peddi 
 * Description: Making sure everything works
 * Due:10/30/22 
 * I pledge that I have completed the programming assignment independently. 
 * I have not copied the code from a student or any source. 
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class BankDriver {
    public static void main(String[] args) throws FileNotFoundException {
        ArrayList<Account> a = new ArrayList<>();
        DecimalFormat b = new DecimalFormat("#0.00");
        Scanner cn = new Scanner(new File("input.txt"));
        while (cn.hasNext()) {
            cn.nextLine();
            String frst = cn.next();
            String lst = cn.next();cn.nextLine();
            String d = cn.nextLine();
            long an = cn.nextLong();cn.nextLine();
            boolean hasLimitedWithdrawals = cn.nextBoolean();cn.nextLine();
            Customer e = new Customer(d, frst, lst);
            Account f = new Account(an, e, hasLimitedWithdrawals);
            System.out.println("------------------------------------------------------------");
            System.out.println("Name of the customer: " + e.getFirstName() + "  " + e.getLastName());
            System.out.println("------------------------------------------------------------");
            while (cn.hasNext() && !cn.hasNext("newAccount")) {
                String g = cn.next();
                double h = cn.nextDouble();
                String i = cn.next();
                String j = cn.next();
                if (cn.hasNext()) { cn.nextLine();}
                String m = i + " " + j;
                DateTimeFormatter k = DateTimeFormatter.ofPattern("yyyy-M-d H:m:s");
                LocalDateTime l = LocalDateTime.parse(m, k);
                Transaction n = new Transaction(g, h, l);
                String p = f.makeTransaction(n);
                if (p.equals("Transaction Successful")) {
                    System.out.println("The balance after " + n.getTransactionType() + " in dollars is " + b.format(Math.round(f.getBalance() * 100) / 100.0));
                }
                if (p.equals("Insufficient Balance")) {
                    System.out.println("Insufficient funds. Available funds: " + b.format(Math.round(f.getBalance() * 100) / 100.0));
                }
                if (p.equals("MaxTransactions")) {
                    System.out.println("Exceeded number of withdrawals transactions. Number of available withdrawals per month: 6");
                }
            }
            a.add(f);
        }
        System.out.println("************************************************************************\n"
                + "*********Invoke getNoofWithdrawals() on Account objects**********\n"
                + "************************************************************************");
        a.forEach((z) -> {
            System.out.println(z.getCustomer().getFirstName() + " made " + z.getNoofWithdrawals() + " withdrawals in this month.");
        });
        System.out.println("***********************************************************************\n"
                + "****Invoke generateStatement() on all objects in a ArrayList****\n"
                + "************************************************************************");
        a.forEach((q) -> {
            System.out.println(q.generateStatement());
        });
    }

}
  
 
