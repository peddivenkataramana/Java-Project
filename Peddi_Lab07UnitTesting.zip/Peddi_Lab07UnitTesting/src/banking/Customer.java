/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

/**
 * Class: 44542-05 Object Oriented Programming
 * @author Venkataramana Peddi 
 * Description: Making sure everything works
 * Due:10/30/22 
 * I pledge that I have completed the programming assignment independently. 
 * I have not copied the code from a student or any source. 
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class Customer {

    private String dob;
    private String firstName;
    private String lastName;

    /**
     * This is a parameterized constructor
     *
     * @param dob
     * @param firstName
     * @param lastName
     */
    public Customer(String dob, String firstName, String lastName) {
        this.dob = dob;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    /**
     * This is a getDob method
     *
     * @return dob
     */
    public String getDob() {
        return dob;
    }

    /**
     * This is a getFirstName
     *
     * @return firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * This is a getLastName
     *
     * @return lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * This is a setDob method
     *
     * @param dob
     */
    public void setDob(String dob) {
        this.dob = dob;
    }

    /**
     * This is a setFirstName method
     *
     * @param firstName
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * This is a setLastName method
     *
     * @param lastName
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Override
    /**
     * This is a toString method
     */
    public String toString() {
        return "Name: " + getLastName() + "," + getFirstName() + "\n" + "Date of Birth: " + getDob();
    }

}
