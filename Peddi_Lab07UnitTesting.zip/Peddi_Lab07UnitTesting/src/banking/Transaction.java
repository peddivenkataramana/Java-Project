/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.text.DecimalFormat;
import java.time.LocalDateTime;

/**
 * Class: 44542-05 Object Oriented Programming
 * @author Venkataramana Peddi 
 * Description: Making sure everything works
 * Due:10/30/22 
 * I pledge that I have completed the programming assignment independently. 
 * I have not copied the code from a student or any source. 
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class Transaction {

    private double additionalCharges;

    private double amount;

    private String status;

    private LocalDateTime transactionTime;

    private String transactionType;

    /**
     * This is a Parameterized constructor
     *
     * @param transactionType
     * @param amount
     * @param transactionTime
     */
    public Transaction(String transactionType, double amount, LocalDateTime transactionTime) {
        this.transactionType = transactionType;
        this.amount = amount;
        this.transactionTime = transactionTime;

    }

    /**
     * This is a getAdditionalCharges method
     *
     * @return additionalCharges
     */
    public double getAdditionalCharges() {
        return additionalCharges;
    }

    /**
     * This is a getAmount method
     *
     * @return amount
     */
    public double getAmount() {
        return amount;
    }

    /**
     * This is a getStatus method
     *
     * @return status
     */
    public String getStatus() {
        return status;
    }

    /**
     * This is a getTransactionTime method
     *
     * @return transactionTime
     */
    public LocalDateTime getTransactionTime() {
        return transactionTime;
    }

    /**
     * This is a getTransactionType method
     *
     * @return transactionType
     */
    public String getTransactionType() {
        return transactionType;
    }

    /**
     * This is a setAdditionalCharges method
     *
     * @param additionalCharges
     */
    public void setAdditionalCharges(double additionalCharges) {
        this.additionalCharges = additionalCharges;
    }

    /**
     * This is a setAmount method
     *
     * @param amount
     */
    public void setAmount(double amount) {
        this.amount = amount;
    }

    /**
     * This is a setStatus method
     *
     * @param status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * This is a setTransactionTime method
     *
     * @param transactionTime
     */
    public void setTransactionTime(LocalDateTime transactionTime) {
        this.transactionTime = transactionTime;
    }

    /**
     * This is a setTransactionType method
     *
     * @param transactionType
     */
    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    @Override
    /**
     * This is a toString
     */
    public String toString() {
        DecimalFormat df = new DecimalFormat("#0.00");
        String a = (this.transactionType.equals("ONLINEPURCHASE")) ? (this.transactionType + "      ") : (this.transactionType + "             ");
        return "\n" + String.format("%-19s %-24s %-15s %-24s %-10s", this.transactionType, this.transactionTime, df.format(this.amount), df.format(this.additionalCharges), this.status);
    }

}
