/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.time.LocalDateTime;

/**
 * Class: 44542-05 Object Oriented Programming
 * @author Venkataramana Peddi 
 * Description: Making sure everything works
 * Due:10/30/22 
 * I pledge that I have completed the programming assignment independently. 
 * I have not copied the code from a student or any source. 
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class Account {

    private final long accountNumber;
    private final Customer customer;
    private double balance;
    private final ArrayList<Transaction> transactions;
    private final boolean hasLimitedWithdrawals;
    public static final double SAVING_INTEREST = 5.80;

    /**
     * This is a parameterized constructor
     *
     * @param accountNumber
     * @param customer
     * @param hasLimitedWithdrawals
     */
    public Account(long accountNumber, Customer customer, boolean hasLimitedWithdrawals) {
        this.accountNumber = accountNumber;
        this.customer = customer;
        this.hasLimitedWithdrawals = hasLimitedWithdrawals;
        transactions = new ArrayList<>();
    }

    /**
     * This is a getAccountNumber method
     *
     * @return accountNumber
     */
    public long getAccountNumber() {
        return accountNumber;
    }

    /**
     * This is a getCustomer method
     *
     * @return customer
     */
    public Customer getCustomer() {
        return customer;
    }

    /**
     * This is a getBalance method
     *
     * @return balance
     */
    public double getBalance() {
        return balance;
    }

    /**
     * This is a getTransactions method
     *
     * @return transactions
     */
    public ArrayList<Transaction> getTransactions() {
        return transactions;
    }

    /**
     * This is a isHasLimitedWithdrawals method
     *
     * @return hasLimitedWithdrawals
     */
    public boolean isHasLimitedWithdrawals() {
        return hasLimitedWithdrawals;
    }

    /**
     * This is a getSAVING_INTEREST method
     *
     * @return SAVING_INTEREST
     */
    public static double getSAVING_INTEREST() {
        return SAVING_INTEREST;
    }

    /**
     * This is a setBalance method
     *
     * @param balance
     */
    public void setBalance(double balance) {
        this.balance = balance;
    }

    /**
     * This is a generate statement method
     */
    public String generateStatement() {
        DecimalFormat a = new DecimalFormat("#0.00");
        String b = customer.toString();
        String c = "Account Number: " + this.accountNumber + "\nAccount Information:-	Interest Rate: "
                + a.format(SAVING_INTEREST) + "%"
                + "\nTransaction Limit for withdrawal: " + (!this.hasLimitedWithdrawals ? "No Limit" : "7 Transactions");
        String d = b
                + "\n" + c
                + "\n-------------------------------------------------------------------------------\n"
                + "Transaction Type    Transaction Time         Amount          Additional Charges       Status    ";
        String e = "";
        e = transactions.stream().map(t -> t.toString()).reduce(e, String::concat);
        return d + e
                + "\n-------------------------------------------------------------------------------\n"
                + "Current Balance: " + a.format(Math.round(this.getBalance() * 100) / 100.0) + "		Interest: $" + a.format(Math.round((this.getBalance() * (SAVING_INTEREST / 100)) * 100) / 100.0)
                + "\n************************************************************************";
    }

    /**
     * This is a getNoofWithdrawals method
     *
     * @return f
     */
    public int getNoofWithdrawals() {
        int f = 0;
        f = transactions.stream().filter(transaction -> (transaction.getTransactionType().equalsIgnoreCase("WITHDRAW")
                && transaction.getTransactionTime().getMonthValue() == 3)).map(_item -> 1).reduce(f, Integer::sum);
        return f;
    }

    /**
     * This is a makeTransaction method
     *
     * @param t
     * @return m
     */
    public String makeTransaction(Transaction t) {
        this.transactions.add(t);
        String m = "";
        if ((t.getTransactionType().equals("WITHDRAW") || t.getTransactionType().equals("ONLINEPURCHASE")) && t.getAmount() > this.balance) {
            t.setAdditionalCharges(0);
            t.setStatus("FAILED");
            m = "Insufficient Balance";
        } else if (t.getTransactionType().equals("DEPOSIT")) {
            t.setAdditionalCharges(0);
            t.setStatus("SUCCESS");
            this.setBalance(balance + t.getAmount());
            m = "Transaction Successful";
        } else if (t.getTransactionType().equals("ONLINEPURCHASE")) {
            t.setAdditionalCharges(1.99);
            t.setStatus("SUCCESS");
            this.setBalance(balance - (t.getAmount() + t.getAdditionalCharges()));
            m = "Transaction Successful";
        } else if (t.getTransactionType().equals("WITHDRAW")) {
            if (hasLimitedWithdrawals) {
                if (this.getNoofWithdrawals() > 6) {
                    t.setAdditionalCharges(0);
                    t.setStatus("FAILED");
                    m = "MaxTransactions";
                }
                if (this.getNoofWithdrawals() <= 6) {
                    t.setAdditionalCharges(0);
                    t.setStatus("SUCCESS");
                    this.setBalance(balance - t.getAmount());
                    m = "Transaction Successful";
                }
            } else {
                if (this.getNoofWithdrawals() > 6) {
                    double additionalChrgs = Math.max(2.59, t.getAmount() * 1 / 100.0);
                    t.setAdditionalCharges(additionalChrgs);
                    t.setStatus("SUCCESS");
                    setBalance(this.balance - (t.getAmount() + additionalChrgs));
                    m = "Transaction Successful";
                }
                if (this.getNoofWithdrawals() <= 6) {
                    t.setAdditionalCharges(0);
                    t.setStatus("SUCCESS");
                    setBalance(balance - t.getAmount());
                    m = "Transaction Successful";
                }
            }

        }

        return m;

    }
}
