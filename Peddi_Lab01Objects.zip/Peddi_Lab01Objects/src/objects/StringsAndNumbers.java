/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objects;
import java.util.Random;

/**
 *
 * @author Venkataramana Peddi
 */
public class StringsAndNumbers {
    public static void main (String[]args){
 
    System.out.println("******** String Class ********");
    
     String splt = new String ("  Welcome     to   the first    Lab Activity  in the    OOP Course ");
   
     
        System.out.println(splt);
        System.out.println("The length of the concatenated string is: "+splt.length());
      
      String splt1 = new String(splt.substring(1,9)) ;
      String splt2 = new String(splt.substring(13,16)) ;
      String splt3 = new String(splt.substring(18,31)) ;
      String splt4 = new String(splt.substring(31,44)) ;
      String splt5 = new String(splt.substring(45,52)) ;
      String splt6 = new String(splt.substring(55,66)) ;
        
    
       String spt1 = splt1.toUpperCase();
       String spt2 = splt2.toUpperCase();
       String spt3 = splt3.toUpperCase();
       String spt4 = splt4.toUpperCase();
       String spt5 = splt5.toUpperCase();
       String spt6 = splt6.toUpperCase();
       
       System.out.println(spt1);
       System.out.println(spt2);
       System.out.println(spt3);
       System.out.println(spt4); 
       System.out.println(spt5);
       System.out.println(spt6);     
       
       String len = "Welcome to the first Lab Activity in the OOP Course!";
        System.out.println("The length of the above string is: "+len.length());
       
              String rp = "lab-interesting-activities-are-activities-lab-Interesting-Lab-Activities-Are Interesting Lab activities Lab Interesting";

              System.out.println("The index of the first occurrence of the word Interesting is "+rp.indexOf("Interesting"));
              
              System.out.println( rp );
       
              String rl = rp.replaceAll("-","_").replaceAll(" ","_");
              System.out.println(rl);
              
              System.out.println("Q)Why  do  you  choose  Applied Computer Science? \nA)To enhance my skills and knowledge.");
          
               System.out.println("\n");
              
              
        //Math Class
        System.out.println("******** Math Class ********");
        // Expression evaluation
        int a = (int) Math.pow(10,2);
        int b = (int) Math.pow(14,2);
        int c = a+b;
        System.out.println("sqrt (10^2+14^2): "+Math.sqrt(c));

        //trignometry
        System.out.println("tan 60° - tan 45° / (1 + tan 60° tan 45°) = "+Math.tan(60-45));

        //Rounded Values
        System.out.println("Rounded Value of cos 45: "+Math.round(Math.cos(45)));
        System.out.println("Rounded Value of cos 27: "+Math.round(Math.cos(27)));
        System.out.println("Rounded Value of tan 45: "+Math.round(Math.tan(45)));
        System.out.println("Rounded Value of tan 27: "+Math.round(Math.tan(27)));

        // Equation
        double equation1 = (double) Math.abs(8* (Math.cos(27)));
        double equation2 = Math.pow((Math.pow(7,4)+(8*6*7)*5),1.0/4);
        double equation3 = Math.pow(Math.pow(5,2)-Math.pow(3,2),1.0/8);
        double result = equation1 * (equation2/equation3);
        System.out.println("The value of given equation is: "+result);

        System.out.println("\n");



        //Random Class
      
        
        System.out.println("******** Random Class ********");
        System.out.println("4 pseudo-random integer values between 0 (inclusive) and 200 (exclusive)");

        int firstValue = random();
        int secondValue = random();
        int thirdValue = random();
        int fourthValue = random();
        System.out.println("First random integer value is: "+firstValue+ " Square of "+firstValue+" is: "+(int)Math.pow(firstValue,2));
        System.out.println("Second random integer value is: "+secondValue+ " Square of "+secondValue+" is: "+(int)Math.pow(secondValue,2));
        System.out.println("Third random integer value is: "+thirdValue+ " Square of "+thirdValue+" is: "+(int)Math.pow(thirdValue,2));
        System.out.println("Fourth random integer value is: "+fourthValue+ " Square of "+fourthValue+" is: "+(int)Math.pow(fourthValue,2));
        
              //3 pseudo-random integer values without seed value and bounds
        System.out.println("3 pseudo-random integer values without seed value and bounds");
        System.out.println("Fifth random integer value is: "+noSeedrandom());
        System.out.println("Sixth random integer value is: "+noSeedrandom());
        System.out.println("Seventh random integer value is: "+noSeedrandom());
        
        System.out.println("Q)Did  you  get  the  same  result  each  time?\nA)NO.");

        System.out.println("4 pseudo-random integer values between 0 (inclusive) and 200 (exclusive)");

        Random random1 = new Random(30);
        
        int firstvalue2 = random1.nextInt(200);
        int secondvalue2 = random1.nextInt(200);
        int thirdvalue2 = random1.nextInt(200);
        int fourthvalue2 = random1.nextInt(200);
        int fifthvalue2=random1.nextInt();
        int sixthvalue2=random1.nextInt();
        int seventhvalue2=random1.nextInt();
        System.out.println("First random integer value is: "+firstvalue2+" Square of "+firstvalue2+" is: "+Math.pow(firstvalue2, 2));
        System.out.println("Second random integer value is: "+secondvalue2+" Square of "+secondvalue2+" is: "+Math.pow(secondvalue2, 2));
        System.out.println("Third random integer value is: "+thirdvalue2+" Square of "+thirdvalue2+" is: "+Math.pow(thirdvalue2, 2));
        System.out.println("Fourth random integer value is: "+fourthvalue2+" Square of "+fourthvalue2+" is: "+Math.pow(fourthvalue2, 2));
        
        //3 pseudo-random integer values with seed value and without bounds
        System.out.println("3 pseudo-random integer values with seed value and bounds");
        System.out.println("Fifth random integer value is: "+fifthvalue2);
        System.out.println("Sixth random integer value is: "+sixthvalue2);
        System.out.println("Seventh random integer value is: "+seventhvalue2);
        System.out.println("Q)id  you  get  the  same  result  each time?\nA)Yes");
        System.out.println("Q)Compare your results from b) and d) and explain the difference?\nA)The seed  will generate the same number sequence every time,but the no seed will generate different number sequence every time. " );
    
        
    }
        
    public static int random(){
        Random random= new Random();
        int x = random.nextInt(200);

        return x;
    }
    public static int noSeedrandom(){
        Random random= new Random();
        int x = random.nextInt();

        return x;
    }
   
}

        
    
    
    

