/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polygon;

import enums.Solids;
import java.text.DecimalFormat;

/**
 * Class: 44542-05 Object Oriented Programming
 * @author Venkataramana Peddi
 * Description: Making sure everything works
 * Due: 11/13/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */

public class Cube extends Square  {
    /**
     * This is a parameterized constructor
     *
     * @param length
     */
    DecimalFormat df = new DecimalFormat("#.00");

    public Cube(double length) {
        super("Cube", length);

    }

    /**
     * This is a get area method
     *
     * @return area
     */
    public double getArea() {
        return (super.getArea() * Solids.CUBE.getNoOfFaces());

    }

    /**
     * This is a get volume method
     *
     * @return volume
     */
    public double getVolume() {
        return ((Math.pow(super.getLength(), 3.0)));
    }

    /**
     * This is a getInSphereRadius method
     *
     * @return radius of sphere
     */
    public double getInSphereRadius() {
        return (super.getLength() / 2);
    }

    /**
     * This is getCircumSphereRadius method
     *
     * @return circular sphere radius
     */
    public double getCircumSphereRadius() {
        return ((Math.sqrt(3.0)) / 2.0) * super.getLength();
    }

    /**
     * This is a toString method
     *
     * @return string
     */
    public String toString() {
        return super.toString()
                + "\n        Insphere radius: " + df.format(getInSphereRadius()) + "cms" + "\n        Circumsphere radius: " + df.format(getCircumSphereRadius()) + "cms" + "\n        Volume: " + df.format(getVolume()) + "cm" + "\u00B3";

    }

}
