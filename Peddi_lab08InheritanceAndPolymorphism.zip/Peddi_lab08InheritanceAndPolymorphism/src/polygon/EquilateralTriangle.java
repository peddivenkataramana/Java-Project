/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polygon;

import java.text.DecimalFormat;

/**
 * Class: 44542-05 Object Oriented Programming
 * @author Venkataramana Peddi
 * Description: Making sure everything works
 * Due: 11/13/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class EquilateralTriangle  extends RegularPolygon {
    
     DecimalFormat df = new DecimalFormat("#.00");

    /**
     * This is a parameterized constructor
     *
     * @param length
     */
    public EquilateralTriangle(double length) {
        super("Equilateral Triangle", 3, length);
    }

    /**
     * This is parameterized constructor
     *
     * @param name
     * @param length
     */
    public EquilateralTriangle(String name, double length) {
        super(name, 3, length);
    }

    /**
     * This is a getHeight method
     *
     * @return height
     */
    public double getHeight() {

        return (((Math.sqrt(3.0)) / 2.0) * super.getLength());
    }

    /**
     * This is toString method
     *
     * @return string
     */
    public String toString() {
        return super.toString()
                + "\n        Height: " + df.format(getHeight()) + "cms";
    }


    
    
    
    
    
    
}
