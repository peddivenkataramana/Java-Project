package polygon;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Class: 44542-05 Object Oriented Programming
 * @author Venkataramana Peddi
 * Description: Making sure everything works
 * Due: 11/13/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public   class Polygon {
   
    private String name;
    private int noSides;

    /**
     * This is a parameterized constructor
     *
     * @param name
     * @param noSides
     */
    public Polygon(String name, int noSides) {
        this.name = name;
        this.noSides = noSides;
    }

    /**
     * This is a getArea method
     *
     * @return 0.0
     */
    public double getArea() {
        return 0.0;
    }

    /**
     * This is a getInternalAngle method
     *
     * @return 0.0
     */
    public double getInternalAngle() {
        return 0.0;
    }

    /**
     * This is a getter method
     *
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * This is a getNoSides method
     *
     * @return noSides
     */
    public int getNoSides() {
        return noSides;
    }

    /**
     * This is a getPerimeter method
     *
     * @return 0.0
     */
    public double getPerimeter() {
        return 0.0;
    }

    /**
     * This is a toString method
     *
     * @return string
     */
    @Override
    public String toString() {
        return "Polygon: " + name + "\n" + "	Number of sides: " + noSides;
    }

}
