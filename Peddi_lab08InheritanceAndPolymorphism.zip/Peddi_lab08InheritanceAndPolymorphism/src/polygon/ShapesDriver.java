/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polygon;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Class: 44542-05 Object Oriented Programming
 * @author Venkataramana Peddi
 * Description: Making sure everything works
 * Due: 11/13/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */ 
public class ShapesDriver {

    public static void main(String[] args) throws FileNotFoundException {
        DecimalFormat df = new DecimalFormat("#.00");
        ArrayList<Polygon> polygonList = new ArrayList<>();
        Scanner s = new Scanner(new File("shapes.txt"));
        double b;
        while (s.hasNext()) {
            String a = s.next();

            if (a.equalsIgnoreCase("cube")) {
                b = s.nextDouble();
                Polygon d = new Cube(b);
                polygonList.add(d);

            } else if (a.equalsIgnoreCase("tetrahedron")) {
                b = s.nextDouble();
                Polygon e = new Tetrahedron(b);
                polygonList.add(e);

            } else if (a.equalsIgnoreCase("triangle")) {
                b = s.nextDouble();
                Polygon f = new EquilateralTriangle(b);
                polygonList.add(f);

            } else if (a.equalsIgnoreCase("square")) {
                b = s.nextDouble();
                Polygon g = new Square(b);
                polygonList.add(g);

            } else {
                int n = s.nextInt();
                b = s.nextDouble();
                Polygon h = new RegularPolygon(a, n, b);
                polygonList.add(h);

            }

        }

        for (Polygon i : polygonList) {
            System.out.println("\n*****************************************");
            System.out.println(i.toString());
        }
        System.out.print("*****************************************");

        double j = 0;
        int k = 0;
        int u = 0;
        for (int i = 0; i < polygonList.size(); i++) {
            if (j < polygonList.get(i).getArea()) {
                j = polygonList.get(i).getArea();
                k = i;
            }
        }
        System.out.println("\nThe polygon with largest area is " + polygonList.get(k).getName() + " with area of " + df.format(j) + "cm" + "\u00B2");
        double p = polygonList.get(0).getArea();

        for (int i = 0; i < polygonList.size(); i++) {
            if (polygonList.get(i).getArea() < p) {
                p = polygonList.get(i).getArea();
                u = i;
            }
        }
        System.out.println("The polygon with smallest area is " + polygonList.get(u).getName() + " with area of " + df.format(p) + "cm" + "\u00B2");
        j=0;k=0;
        for (int i = 0; i < polygonList.size(); i++) {
            if (j < polygonList.get(i).getPerimeter()) {
                j = polygonList.get(i).getPerimeter();
                k = i;
            }
        }
        System.out.println("The polygon with largest perimeter is " + polygonList.get(k).getName() + " with perimeter of " + df.format(j) + "cms");
        
        p = polygonList.get(0).getPerimeter();
            for (int i = 0; i < polygonList.size(); i++) {
            if (polygonList.get(i).getPerimeter() < p) {
                p = polygonList.get(i).getPerimeter();
                u = i;
            }
        }
        System.out.println("The polygon with smallest perimeter is " + polygonList.get(u).getName() + " with perimeter of " + df.format(p) + "cms");
        System.out.println("*****************************************");
        System.out.println("Surface area to Volume ratio of given solids are:");
        for (Polygon w : polygonList) {
            if (w.getClass().getSimpleName().equals("Cube")) {
                Cube q = new Cube(w.getPerimeter() / w.getNoSides());
                System.out.println(w.getName() + ":");

                System.out.println("        Surface area: " + df.format(w.getArea()) + "cm" + "\u00B2" + "\n        Volume: " + df.format(q.getVolume()) + "cm" + "\u00b3");
            }
            if (w.getClass().getSimpleName().equals("Tetrahedron")) {
                Tetrahedron z = new Tetrahedron(w.getPerimeter() / w.getNoSides());
                System.out.println(w.getName() + ":");

                System.out.println("        Surface area: " + df.format(w.getArea()) + "cm" + "\u00B2" + "\n        Volume: " + df.format(z.getVolume()) + "cm" + "\u00b3");

            }
        }
        System.out.println("******************************************");
        System.out.println("During the toString and getvolume methods call in the loops the late binding is used in ShapesDriver class\n");
        System.out.println("******************************************\n");
        System.out.println("In ShapesDriver class the while loop polymorphic substitution is used. \n");
        System.out.println("******************************************");

    }
}
