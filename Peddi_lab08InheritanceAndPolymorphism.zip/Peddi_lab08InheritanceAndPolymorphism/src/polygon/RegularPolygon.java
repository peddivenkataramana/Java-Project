/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polygon;
import java.text.DecimalFormat;
import java.util.*;

/**
 * Class: 44542-05 Object Oriented Programming
 * @author Venkataramana Peddi
 * Description: Making sure everything works
 * Due: 11/13/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class RegularPolygon extends Polygon {
  
    private double length;
    DecimalFormat df = new DecimalFormat("#.00");

    /**
     * This is a parameterized constructor
     *
     * @param name
     * @param noSides
     * @param length
     */
    public RegularPolygon(String name, int noSides, double length) {
        super(name, noSides);
        this.length = length;
    }

    /**
     * This is a getter method
     *
     * @return length
     */
    public double getLength() {
        return length;
    }

    /**
     * This is a getArea method
     *
     * @return area
     */
    public double getArea() {

        return (super.getNoSides() * length * length * (1 / Math.tan(Math.PI / super.getNoSides()))) * (1.0 / 4.0);

    }

    /**
     * This is a getPerimeter method
     *
     * @return perimeter
     */
    public double getPerimeter() {
        return getNoSides() * length;
    }

    /**
     * This is a getInternalAngle method
     *
     * @return internal angle
     */
    public double getInternalAngle() {

        return 180 / getNoSides() * (getNoSides() - 2);
    }

    /**
     * This is a getInCircleRadius method
     *
     * @return in circle radius
     */
    public double getInCircleRadius() {

        return (length / 2) * (1 / (Math.tan(Math.PI / super.getNoSides())));//length/2 *(1/Math.tan(22/7*getNoSides()));
    }

    /**
     * This is a getCircumCircleRadius method
     *
     * @return circum circle radius
     */
    public double getCircumCircleRadius() {
        return (length / 2) * (1 / (Math.sin(3.14 / super.getNoSides())));
    }

    /**
     * This is a toString method
     *
     * @return string
     */
    @Override
    public String toString() {
        return super.toString() + "\n	Length of side: " + length + "cms" + "\n	Internal angle: " + df.format(getInternalAngle() * 100 / 100) + "\u00b0" + "\n	Circumcircle radius: " + df.format(getCircumCircleRadius()) + "cms" + "\n	Incircle radius: " + df.format(getInCircleRadius()) + "cms" + "\n	Area: " + df.format(getArea()) + "cm\u00b2"+ "\n	Perimeter: " + df.format(getPerimeter()) + "cms";

    }

}
