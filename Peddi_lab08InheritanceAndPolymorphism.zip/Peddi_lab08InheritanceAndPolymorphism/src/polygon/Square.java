/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polygon;

/**
 * Class: 44542-05 Object Oriented Programming
 * @author Venkataramana Peddi
 * Description: Making sure everything works
 * Due: 11/13/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class Square extends RegularPolygon {
    /**
     * This is a parameterized constructor
     *
     * @param length
     */
    public Square(double length) {
        super("Square", 4, length);
    }

    /**
     * This is a parameterized constructor
     *
     * @param name
     * @param length
     */
    public Square(String name, double length) {
        super(name, 4, length);
    }

}
