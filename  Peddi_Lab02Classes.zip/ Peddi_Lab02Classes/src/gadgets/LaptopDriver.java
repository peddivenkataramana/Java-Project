/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gadgets;

/**
 *This is a LaptopDriver class
 * @author S554220
 */
public class LaptopDriver {
    
    public static void main(String[]args){
     
   Laptop obj1Laptop = new Laptop("HP","Intel Core i5", "windows",512,12.4,true);
   
        System.out.println("*Testing getter method on obj1Laptop *");
        
        System.out.println("Laptop Brandis :"+obj1Laptop.getBrand());
         System.out.println("Name of the processor is:"+obj1Laptop.getProcessor());
          System.out.println("Operating System name:"+obj1Laptop.getOsName());
           System.out.println("Hard Drive capacity in GB's:"+obj1Laptop.getMemorySize());
           System.out.println("Screen Size:"+obj1Laptop.getScreenSize());
           System.out.println("is Touch:"+obj1Laptop.getisTouch());
                      System.out.println("*Testing toString method on obj1Laptop*");
                      System.out.print( obj1Laptop.toString());
            Laptop obj2Laptop = new Laptop();
           System.out.println("*Testing toString method on obj2Laptop*");
                System.out.print( obj2Laptop.toString());
             obj2Laptop.setBrand("Apple");
            obj2Laptop.setProcessor("Intel core i3 ");
            obj2Laptop.setOsName("macOS Mojave");
            obj2Laptop.setMemorySize(256);
            obj2Laptop.setScreenSize(10.5);
            obj2Laptop.setTouch(false);
                System.out.println("*Testing toString method on obj2Laptop*");
                    System.out.print(obj2Laptop.toString());
                System.out.println("*Testing getter method on obj2Laptop*");
                         System.out.println("Laptop Brandis "+obj2Laptop.getBrand());
             System.out.println("Name of the processor is:"+obj2Laptop.getProcessor());
             System.out.println("Operating System name:"+obj2Laptop.getOsName());
             System.out.println("Hard Drive capacity in GB's:"+obj2Laptop.getMemorySize());
             System.out.println("Screen Size:"+obj2Laptop.getScreenSize());
             System.out.println("is Touch:"+obj2Laptop.getisTouch());
           
    
    
    } 
    
}
