/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gadgets;

/**
 *
 * @author Venkataramana Peddi
 * This is a Laptop class
 */
public class Laptop {
    
 private String brand;
 private String processor;
 private double screenSize;
 private int memorySize;
 private String osName;
 private boolean touch;
 
 /**
  * This is a parameterized constructor 
  * @param brand
  * @param processor
  * @param osName
  * @param memorySize
  * @param screenSize
  * @param touch 
  */

    public Laptop(String brand, String processor, String osName, int memorySize,double screenSize, boolean touch) {
        this.brand = brand;
        this.processor = processor;
        this.screenSize = screenSize;
        this.memorySize = memorySize;
        this.osName = osName;
        this.touch = touch;
    }
   
   /**
    * This is a default constructor
    */
   public Laptop(){//a no-argument constructor with empty body}
       
   }
    /**
     * This is a getter method
     * getBrand method
     * @return brand
     */
    public String getBrand() {
        return brand;
    }
    /**
     * This is a getter method
     * getProcessor method
     * @return processor
     */
    public String getProcessor() {
        return processor;
    }
     /**
      * This is a getter method
      * getOsName method
      * @return osName
      */
        public String getOsName() {
        return osName;
    }
      /**
       * This is a getter method
       * getMemorySize method
       * @return memorySize
       */
        public int getMemorySize() {
        return memorySize;
    }
       /**
        * This is a getter method
        * getScreenSize method
        * @return screenSize
        */
        public double getScreenSize() {
        return screenSize;
    }
        /**
         * This is a getter method
         * getisTouch method
         * @return touch
         */
            
         public boolean getisTouch() {
            return touch;
    }

    /**
     * This is a setter method
     * setBrand method
     * @param brand 
     */
    
        public void setBrand(String brand) {
        this.brand = brand;
    }
        /**
         * This is a setter method
         * setProcessor method
         * @param processor 
         */
        
         public void setProcessor(String processor) {
        this.processor = processor;
    }
         /**
          * This is a setter method
          * setScreenSize method
          * @param screenSize 
          */
        public void setScreenSize(double screenSize) {
        this.screenSize = screenSize;
    }
        /**
         * This is a setter method
         * setMemorySize method
         * @param memorySize 
         */
        public void setMemorySize(int memorySize) {
        this.memorySize = memorySize;
    }
        /**
         * This is a setter method
         * setOsName method
         * @param osName 
         */
         public void setOsName(String osName) {
        this.osName = osName;
    }
        /**
         * This is a setter method
         * setTouch method
         * @param touch 
         */
        public void setTouch(boolean touch) {
        this.touch = touch;
    }
        /**
         * This is a toString method
         */
    @Override
    public String toString() {
        return "Laptop Brand :" + brand+"\r\n"  + "Laptop processor : " + processor+"\r\n"  + "Laptop Operating System :" + osName+"\r\n"  +"Laptop Hard Drive :" + memorySize+"\r\n"  + "Laptop Display:" + screenSize+"\r\n"  + "Laptop Is Touch:" + touch+"\r\n" ;
    }
    
   
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
