/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employeeSalary;
import java.util.Scanner;
/**
 *This is a EmployeeSalaryDriver
 * @author S554220
 */
public class EmployeeSalaryDriver {
    
    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in);
        System.out.println("Testing the EmployeeSalary class:"+"\u001B[31m");
        System.out.print("Enter the wage per hour of the Employee: $");
        double hourlyRate = scan.nextDouble();
        System.out.print("Enter the insurance  percentage of the Employee in percentage: ");
        double insuranceRate = scan.nextDouble();
        System.out.print("Enter the tax  percentage  of the Employee in percentage: ");
        double taxRate = scan.nextDouble();
        System.out.print("Enter the pf percentage of the Employee in percentage: ");
        double pfRate = scan.nextDouble();
        System.out.print("Enter the bonus of the Employee: ");
        double bonus = scan.nextDouble();
        System.out.println("The details of obj1EmpSal object are as follows:");
       
        EmployeeSalary obj1EmpSal = new EmployeeSalary(hourlyRate, insuranceRate, taxRate, pfRate);
        System.out.println(obj1EmpSal.toString());
        System.out.println("The monthly salary of the Employee is: $" + obj1EmpSal.calcMonthlySalary());
        System.out.println("The monthly insurance of the Employee is: $" + obj1EmpSal.calcMonthlyInsurance());
        System.out.println("The monthly pf of the Employee is: $" + obj1EmpSal.calcMonthlyPfAmount());
        System.out.println("The annual gross salary of the Employee is: $" + obj1EmpSal.calcAnnualGrossSalary(bonus));
        System.out.println("The gross annual net pay of the Employee is: $" + obj1EmpSal.calcAnnualNetPay(bonus));
        System.out.println("************************************************************");
       
        EmployeeSalary obj2EmpSal = new EmployeeSalary();
        System.out.println("The details of empSalObj2 object are as follows:");
        System.out.println(obj2EmpSal.toString());
        System.out.println("The monthly salary of the Employee is: $" + obj2EmpSal.calcMonthlySalary());
        System.out.println("The monthly insurance of the Employee is: $" + obj2EmpSal.calcMonthlyInsurance());
        System.out.println("The monthly pf of the Employee is: $" + obj2EmpSal.calcMonthlyPfAmount());
        System.out.println("The annual gross salary of the Employee is: $" + obj2EmpSal.calcAnnualGrossSalary(bonus));
        System.out.println("The gross annual net pay of the Employee is: $" + obj2EmpSal.calcAnnualNetPay(bonus));
        obj2EmpSal.setWagePerHour(35.0);
        obj2EmpSal.setInsurancePercentage(12.50);
        obj2EmpSal.setTaxPercentage(11.45);
        obj2EmpSal.setPfPercentage(10.5);
        System.out.print("Enter the new bonus of the Employee: ");
       double b = scan.nextDouble();
        System.out.println("The details of obj2EmpSal object are as follows:");
        System.out.println(obj2EmpSal.toString());
        System.out.println("The monthly salary of the Employee is: $" + obj2EmpSal.calcMonthlySalary());
        System.out.println("The monthly insurance of the Employee is: $" + obj2EmpSal.calcMonthlyInsurance());
        System.out.println("The monthly pf of the Employee is: $" + obj2EmpSal.calcMonthlyPfAmount());
        System.out.println("The annual gross salary of the Employee is: $" + obj2EmpSal.calcAnnualGrossSalary(bonus));
        System.out.println("The gross annual net pay of the Employee is: $" + obj2EmpSal.calcAnnualNetPay(bonus));
    }
    
}
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
   