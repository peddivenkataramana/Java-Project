/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employeeSalary;

/**
 * This is EmployeeSalary class 
 * @author Venkataramana Peddi
 */
public class EmployeeSalary {
    
   private double wagePerHour;
   private  double insurancePercentage;
   private  double taxPercentage;
   private  double pfPercentage;
   private static final int HOURS = 40;
     
   /**
    * This is a parameterized constructor
    * @param wagePerHour
    * @param insurancePercentage
    * @param taxPercentage
    * @param pfPercentage 
    */
    public EmployeeSalary(double wagePerHour, double insurancePercentage, double taxPercentage, double pfPercentage) {
        this.wagePerHour = wagePerHour;
        this.insurancePercentage = insurancePercentage;
        this.taxPercentage = taxPercentage;
        this.pfPercentage = pfPercentage;
      
    }
    /**
     * This is a default constructor
     */
    public EmployeeSalary() {
    }
    /**
     * This is a getter method
     * getWagePerHour method
     * @return wagePerHour
     */
    public double getWagePerHour() {
        return wagePerHour;
    }
    /**
     * This is a getter method
     * getInsurancePercentage method
     * @return insurancePercentage
     */
    public double getInsurancePercentage() {
        return insurancePercentage;
    }
    /**
     * This is a getter method
     * getTaxPercentage method
     * @return taxPercentage
     */
    public double getTaxPercentage() {
        return taxPercentage;
    }
    /**
     * This is a getter method
     * getPfPercentage method
     * @return pfPercentage
     */
    public double getPfPercentage() {
        return pfPercentage;
    }
    /**
     * This is a getter method
     * getHours method
     * @return HOURS
     */
    public int getHOURS() {
        return HOURS;
    }
    /**
     * This is a setter method 
     * setWagePerHour method 
     * @param wagePerHour 
     */
    public void setWagePerHour(double wagePerHour) {
        this.wagePerHour = wagePerHour;
    }
    /**
     * This is a setter method 
     * setInsurancePercentage method 
     * @param insurancePercentage 
     */
    public void setInsurancePercentage(double insurancePercentage) {
        this.insurancePercentage = insurancePercentage;
    }
    /**
     * This is a setter method 
     * setTaxPercentage method 
     * @param taxPercentage 
     */
    public void setTaxPercentage(double taxPercentage) {
        this.taxPercentage = taxPercentage;
    }
    /**
     * This is a setter method 
     * setPfPercentage method 
     * @param pfPercentage 
     */
    public void setPfPercentage(double pfPercentage) {
        this.pfPercentage = pfPercentage;
    }
    
    /**
     * This a method for monthly salary calculation
     * calcMonthlySalary method
     */
    
    public double calcMonthlySalary(){
        
        return HOURS*4*this.wagePerHour;
         
    }
    /**
     * This is a method for monthly insurance calculation
     * calcMonthlyInsurance method 
     */
    public double  calcMonthlyInsurance(){
        
        
        double Monthlyinsurance=this.calcMonthlySalary()*(this.insurancePercentage)/100;
   
          return Monthlyinsurance;
         
      
    }
    
    /**
     * This is a method for monthly pf calculation
     * calcMonthlyPfAmount method
     * @return MonthlyPFAmount
     */
   public double calcMonthlyPfAmount(){
       
       double  MonthlyPFAmount= this.calcMonthlySalary()*(this.pfPercentage)/100;
      return MonthlyPFAmount;
   }
    /**
     * This is a method for annual gross salary calculation 
     * calcAnnualGrossSalary method
     * @param bonus
     * @return Annual gross salary
     */
    public double calcAnnualGrossSalary(double bonus){
        
      double Annualgrosssalary= bonus + (this.calcMonthlySalary()*12);
       return Annualgrosssalary; 
    }
    /**
     * This is a method for annual net pay calculation
     * calcAnnualNetPay method 
     * @param bonus
     * @return AnnualNetPay
     */
    public double calcAnnualNetPay(double bonus){
       double AnnualNetPay = this.calcAnnualGrossSalary(bonus) - (this.calcAnnualGrossSalary(bonus) * this.taxPercentage / 100) - (this.calcMonthlyInsurance() * 12) - (this.calcMonthlyPfAmount() * 12);
       return AnnualNetPay;
    }
    /**
     * This is a toString method
       */
    @Override
    public String toString() {
return "wagePerHour: " + wagePerHour + ", insurancePercentage: " + insurancePercentage + ", taxPercentage: " + taxPercentage + ", pfPercentage: " + pfPercentage + ", HOURS: " + HOURS;    }

    
    
    
    
}
