/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shopping;

import java.util.Scanner;

/**
 * This is a Creator class
 *
 * @author Venkataramana Peddi
 */
public class Creator {

    /**
     * This is a createStore method
     *
     * @param name
     * @return Store
     */
    public Store createStore(String name) {

        if (name.equalsIgnoreCase("Grocery")) {
            Store a = new GroceryStore();
            return a;
        } else {
            Store a = new MedicineStore();
            return a;
        }
    }

}
