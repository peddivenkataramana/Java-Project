/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shopping;

/**
 * This is a GroceryStore class
 *
 * @author Venkataramana Peddi
 */
public class GroceryStore extends Store {

    /**
     * This is a createGroceryStore method
     *
     * @param name
     * @return grocery
     */
    public Grocery createGroceryStore(String name) {

        if (name.equals("Wallmart")) {
            Grocery a = new WallMart();
            return a;
        } else {
            Grocery b = new Hyvee();
            return b;
        }
    }

    /**
     * This is a createMedicineStore method
     *
     * @param name
     * @return Medicine
     */
    public Medicine createMedicineStore(String name) {
        return null;
    }

}
