/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shopping;

import java.util.Scanner;

/**
 * This is a wallmart class
 *
 * @author Venkataramana Peddi
 */
public class WallMart implements Grocery {

    private double total;

    /**
     * This is a no args constructor
     */
    public WallMart() {
        total = 0.0;
    }

    /**
     * This is a getter method
     *
     * @return total
     */
    public double getTotal() {
        return total;
    }

    /**
     * This is a buyItems method
     */
    public void buyItems() {
        boolean moreItem = true;

        while (moreItem) {
            Scanner sc = new Scanner(System.in);

            System.out.print("Enter the name of item:");
            String n = sc.next();
            System.out.print("Enter the price of " + n + ":");
            double p = sc.nextDouble();
            total = total + p;
            System.out.print("Do you want to buy more items (Y/N):");
            String more = sc.next();
            if (more.equals("Y")) {
                moreItem = true;
            } else {
                moreItem = false;
            }

        }
    }

}
