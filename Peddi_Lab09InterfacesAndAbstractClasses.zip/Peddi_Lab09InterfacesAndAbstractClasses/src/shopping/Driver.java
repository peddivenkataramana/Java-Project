/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shopping;

import java.util.Scanner;

/**
 * This is a driver class
 *
 * @author Venkataramana Peddi
 */
public class Driver {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Creator objCreator = new Creator();
        System.out.print("Enter what you want to buy (Grocery/Medicine):");
        String a = sc.next();
        Store objStore = objCreator.createStore(a);
        if (a.equalsIgnoreCase("Grocery")) {
            System.out.print("Enter the grocery store name from which you want to buy (Wallmart/Hyvee):");
            String b = sc.next();
            Grocery objGrocery = objStore.createGroceryStore(b);
            objGrocery.buyItems();
            System.out.println("Total price for the shopping is:" + objGrocery.getTotal());
        } else if (a.equals("Medicine")) {
            System.out.print("Enter the medicine store name from which you want to buy (Wallgreen/Mosaic):");
            String c = sc.next();
            Medicine objMedicine = objStore.createMedicineStore(c);
            objMedicine.buyItems();
            System.out.println("Total price for the shopping is:" + objMedicine.getTotal());
        }

    }

}
