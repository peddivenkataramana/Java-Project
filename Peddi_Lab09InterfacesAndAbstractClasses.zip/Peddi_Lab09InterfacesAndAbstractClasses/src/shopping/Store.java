/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shopping;

/**
 * This is a abstract store class
 *
 * @author Venkataramana Peddi
 */
public abstract class Store {

    /**
     * This is a abstract Grocery method
     *
     * @param name
     * @return grocery
     */
    public abstract Grocery createGroceryStore(String name);

    /**
     * This is a abstract medicine method
     *
     * @param name
     * @return medicine
     */
    public abstract Medicine createMedicineStore(String name);

}
