/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shopping;

/**
 * This is a MedicineStore class
 *
 * @author Venkataramana Peddi
 */
public class MedicineStore extends Store {

    /**
     * This is a createGroceryStore method
     *
     * @param name
     * @return null
     */
    public Grocery createGroceryStore(String name) {
        return null;
    }

    /**
     * This is a createMedicineStore method
     *
     * @param name
     * @return Medicine
     */
    public Medicine createMedicineStore(String name) {

        if (name.equals("Wallgreen")) {

            Medicine a = new WallGreen();
            return a;
        } else {
            Medicine a = new Mosaic();
            return a;
        }

    }

}
