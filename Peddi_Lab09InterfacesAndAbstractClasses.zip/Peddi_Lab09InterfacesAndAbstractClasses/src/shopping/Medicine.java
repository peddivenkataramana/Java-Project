/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shopping;

/**
 * This is a medicine interface
 *
 * @author Venkataramana Peddi
 */
public interface Medicine {

    /**
     * This is a buyItems method
     */
    public void buyItems();

    /**
     * This is a getTotal method
     *
     * @return total
     */
    public double getTotal();

}
