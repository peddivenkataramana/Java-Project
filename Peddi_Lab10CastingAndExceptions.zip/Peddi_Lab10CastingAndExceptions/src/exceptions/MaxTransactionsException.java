/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptions;

/**
 * This exception is called when the number of withdrawal transactions made by
 * the customer of an account exceeds the max limit allowed within a specified
 * amount of time.
 *
 * @author Venkataramana Peddi
 */
public class MaxTransactionsException extends Exception {

    /**
     * Creates a new instance of MaxTransactionsException without detail
     * message.
     */
    public MaxTransactionsException() {
    }

}
