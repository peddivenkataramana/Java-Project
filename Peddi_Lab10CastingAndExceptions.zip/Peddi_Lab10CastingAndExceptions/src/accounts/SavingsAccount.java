/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accounts;

import enums.TransactionType;
import exceptions.InsufficentFundsException;
import exceptions.MaxTransactionsException;
import java.time.LocalDateTime;
import java.time.Month;

/**
 * This class extends the Account class implementing all the abstract method.
 * This class is built on the below provided definition of savings account. A
 * savings account is an interest-bearing deposit account held at a financial
 * institution that provides a modest interest rate. The financial institutions
 * may limit the number of withdrawals you can make from your savings account
 * each month. They also may charge additional fees for withdrawals made after a
 * certain monthly limit specified for these account.
 *
 * @author Venkataramana Peddi
 */
public class SavingsAccount extends Account {

    /**
     * An attribute that stores a boolean flag to determine if there is a limit
     * on number of withdrawals within a month.
     */
    public boolean hasLimitedWithdrawals;

    /**
     * An three argument constructor that initializes the instance variables of
     * with the values passed.
     *
     * @param customer
     * @param accountNumber
     * @param hasLimitedWithdrawals
     */
    public SavingsAccount(Customer customer, long accountNumber, boolean hasLimitedWithdrawals) {
        super(customer, accountNumber);
        this.hasLimitedWithdrawals = hasLimitedWithdrawals;
    }

    /**
     * This method generates the statement for an account in a specified format.
     *
     * @return statement
     */
    @Override
    public String generateStatement() {
        String a;
        if (hasLimitedWithdrawals == true) {
            a = "6 Transactions";
        } else {
            a = "No limit";
        }
        String b = "\n-------------------------------------------------------------------------------\n";
        String c = "";
        for (Transaction d : super.getTransactions()) {
            c += d.toString() + "\n";
        }
        String d = c.substring(0, c.length() - 1);
        return toString() + "\nTransaction Limit for withdrawal: " + a + b + "Transaction Type\tTransaction Time\tAmount\tAdditional Charges\tStatus\n" + d + b + "Current Balance: " + String.format("%.2f", super.getBalance()) + "\t\tInterest: $" + String.format("%.2f", interestCalculator());
    }

    /**
     * This method returns the number of withdrawal transactions made by a
     * customer for an account in the current month using the system date.
     *
     * @return noofwithdrawls
     */
    public int getNoofWithdrawals() {
        int e = 0;
        LocalDateTime f = LocalDateTime.now();
        Month g = f.getMonth();
        for (Transaction h : super.getTransactions()) {
            if (h.getTrannsactonTime().getMonth() == g) {
                if (h.getTransactionType() == TransactionType.WITHDRAW) {
                    e++;
                }
            }
        }
        return e;
    }

    /**
     * This overriding method returns the details of an account.
     *
     * @return toString
     */
    @Override
    public String toString() {
        return super.toString() + "\nAccount Type: Savings Account\tInterest Rate: 5.80%";
    }

    /**
     * This method takes transaction object as parameter and performs necessary
     * action, based on the transaction type.
     *
     * @param transaction
     * @return transaction
     * @throws InsufficentFundsException
     * @throws MaxTransactionsException
     */
    @Override
    public double makeTransaction(Transaction transaction) throws InsufficentFundsException, MaxTransactionsException {
        double k = 0.0;

        int j = getNoofWithdrawals();
        if (transaction.getTransactionType() == TransactionType.DEPOSIT) {
            transaction.setAdditionalCharges(0.0);
            transaction.setStatus("SUCCESS");
            k = super.getBalance() + transaction.getAmount();
            transactions.add(transaction);
        } else if (transaction.getTransactionType() == TransactionType.ONLINEPURCHASE) {
            if (transaction.getAmount() < super.getBalance()) {
                transaction.setAdditionalCharges(1.99);
                transaction.setStatus("SUCCESS");
                k = super.getBalance() - (transaction.getAmount() + transaction.getAdditionalCharges());
                transactions.add(transaction);
            } else {
                transaction.setAdditionalCharges(0.0);
                transaction.setStatus("FAILED");
                k = super.getBalance();
                transactions.add(transaction);
                throw new InsufficentFundsException();
            }
        } else {
            if (transaction.getAmount() <= super.getBalance() && hasLimitedWithdrawals == false) {
                if (j <= 6) {
                    transaction.setAdditionalCharges(0.0);
                    transaction.setStatus("SUCCESS");
                    k = super.getBalance() - transaction.getAmount();
                    transactions.add(transaction);
                    j++;
                } else if (j > 6) {
                    if (0.01 * transaction.getAmount() >= 2.59) {
                        transaction.setAdditionalCharges(0.01 * transaction.getAmount());
                    } else {
                        transaction.setAdditionalCharges(2.59);
                    }
                    transaction.setStatus("SUCCESS");
                    k = super.getBalance() - (transaction.getAmount() + transaction.getAdditionalCharges());
                    transactions.add(transaction);
                    j++;
                }
            } else if (transaction.getAmount() <= super.getBalance() && hasLimitedWithdrawals == true) {
                if (j <= 6) {
                    transaction.setAdditionalCharges(0.0);
                    transaction.setStatus("SUCCESS");
                    k = super.getBalance() - transaction.getAmount();
                    transactions.add(transaction);
                    j++;
                } else if (j >= 6) {
                    transaction.setAdditionalCharges(0.0);
                    transaction.setStatus("FAILED");
                    k = super.getBalance();
                    transactions.add(transaction);
                    throw new MaxTransactionsException();
                }
            } else if (transaction.getAmount() > super.getBalance()) {
                transaction.setAdditionalCharges(0.0);
                transaction.setStatus("FAILED");
                k = super.getBalance();
                transactions.add(transaction);
                throw new InsufficentFundsException();
            }
        }
        super.setBalance(k);
        return k;
    }

    /**
     * This is interestCalculator method
     *
     * @return interest value
     */
    private double interestCalculator() {
        return super.getBalance() * (SAVING_INTEREST / 100);
    }
}
