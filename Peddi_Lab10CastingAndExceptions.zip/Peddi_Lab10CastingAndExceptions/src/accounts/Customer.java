/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accounts;

/**
 * This class contains details of a customer like name, date of birth etc.
 *
 * @author Venkataramana Peddi
 */
public class Customer {

    /**
     * Attribute that stores the first name of the customer
     */
    public String firstName;
    /**
     * Attribute that stores the last name of the customer
     */
    public String lastName;
    /**
     * Attribute that stores the date of birth of the customer in MM/DD/YYYY
     * format
     */
    public String dob;

    /**
     * An all argument constructor that takes first name, last name and date of
     * birth as parameters to initialize the instance variables.
     *
     * @param firstName
     * @param lastName
     * @param dob
     */
    public Customer(String firstName, String lastName, String dob) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.dob = dob;
    }

    /**
     * The getter method that returns the first name of the customer
     *
     * @return firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * The getter method that returns the last name of the customer
     *
     * @return lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * The getter method that returns the date of birth of a customer
     *
     * @return
     */
    public String getDob() {
        return dob;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    /**
     * This overriding method returns the formatted string containing the
     * details of a customer.
     *
     * @return toString
     */
    @Override
    public String toString() {
        return "Name: " + lastName + ", " + firstName + "\nDate of Birth: " + dob;
    }

}
