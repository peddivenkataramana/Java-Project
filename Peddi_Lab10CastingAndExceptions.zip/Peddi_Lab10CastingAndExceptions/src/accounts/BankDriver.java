/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accounts;

import enums.TransactionType;
import exceptions.InsufficentFundsException;
import exceptions.MaxTransactionsException;
import exceptions.OverdraftLimitExceededException;
import java.io.File;
import java.io.FileNotFoundException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * The driver class to test all the classes
 *
 * @author Venkataramana Peddi
 */
public class BankDriver {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {

        ArrayList<Account> a = new ArrayList<>();
        Scanner b = new Scanner(new File("input.txt"));
        String c = "";
        SavingsAccount d = null;
        CurrentAccount e = null;
        String f = b.nextLine();
        while (b.hasNext()) {
            if (!c.isEmpty()) {
                f = c;
            }
            String g = b.nextLine();
            String[] h = g.split(" ");
            System.out.println("------------------------------------------------------------");
            System.out.println("Name of the customer: " + h[0] + "  " + h[1]);
            System.out.println("------------------------------------------------------------");
            String i = b.nextLine();
            Customer j = new Customer(h[0], h[1], i);
            long k = b.nextLong();
            b.nextLine();
            if (f.equals("savings")) {
                boolean l = b.nextBoolean();
                d = new SavingsAccount(j, k, l);
                b.nextLine();
            } else {
                e = new CurrentAccount(j, k);
            }
            c = b.nextLine();
            do {
                String m = c;
                String[] n = m.split(" ");
                TransactionType o;
                switch (n[0]) {
                    case "DEPOSIT":
                        o = TransactionType.DEPOSIT;
                        break;
                    case "WITHDRAW":
                        o = TransactionType.WITHDRAW;
                        break;
                    case "ONLINEPURCHASE":
                        o = TransactionType.ONLINEPURCHASE;
                        break;
                    default:
                        o = TransactionType.DEPOSIT;
                        break;
                }
                String[] p = n[2].split("-");
                int q = Integer.parseInt(p[0]);
                int r = Integer.parseInt(p[1]);
                int s = Integer.parseInt(p[2]);
                String[] t = n[3].split(":");
                int u = Integer.parseInt(t[0]);
                int v = Integer.parseInt(t[1]);
                int w = Integer.parseInt(t[2]);
                LocalDateTime x = LocalDateTime.of(q, r, s, u, r, s);
                Transaction y = new Transaction(o, Double.parseDouble(n[1]), x);
                try {
                    if (f.equals("savings")) {
                        d.makeTransaction(y);
                        System.out.println("The balance after " + o + " in dollars is " + String.format("%.2f", d.getBalance()));
                    } else {
                        e.makeTransaction(y);
                        System.out.println("The balance after " + o + " in dollars is " + String.format("%.2f", e.getBalance()));
                    }
                } catch (OverdraftLimitExceededException exe) {
                    System.out.println("exceptions.OverdraftLimitExceededException");

                } catch (MaxTransactionsException exe) {
                    System.out.println("exceptions.MaxTransactionsException");
                } catch (InsufficentFundsException exe) {
                    System.out.println("exceptions.InsufficentFundsException");
                }
                if (b.hasNext()) {
                    c = b.nextLine();
                } else {
                    break;
                }
            } while (c.contains("DEPOSIT") || c.contains("WITHDRAW") || c.contains("ONLINEPURCHASE"));
            if (f.equals("savings")) {
                a.add(d);
            } else {
                a.add(e);
            }
        }
        System.out.println("************************************************************************\n"
                + "*********Invoke getNoofWithdrawals() on SavingsAccount objects**********\n"
                + "************************************************************************");
        for (Account ac : a) {
            if (ac.toString().contains("Savings")) {
                SavingsAccount savingsAccount = (SavingsAccount) ac;
                System.out.println(ac.getCustomer().getFirstName() + " made " + savingsAccount.getNoofWithdrawals() + " withdrawals in this month.");
            }
        }
        System.out.println("***********************************************************************\n"
                + "****Invoke generateStatement() on all objects in accounts ArrayList****\n"
                + "************************************************************************");
        for (Account ac : a) {
            System.out.println(ac.generateStatement());
            System.out.println("*******************************************************************************");
        }
    }

}
