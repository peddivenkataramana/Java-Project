/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accounts;

import interfaces.Operations;
import java.util.ArrayList;

/**
 * This abstract class contains attributes and methods of a bank account
 * implementing the Operations.
 *
 * @author Venkataramana Peddi
 */
public abstract class Account implements Operations {

    /**
     * Attribute that stores the account number of a customer.
     */
    public long accountNumber;
    /**
     * Attribute that stores the account balance of a customer.
     */
    public double balance;
    /**
     * Attribute that stores the details of a customer as a Customer object.
     */
    public Customer customer;
    /**
     * Attribute that stores details of all the transactions performed by a
     * customer.
     */
    public ArrayList<Transaction> transactions;

    /**
     * A two argument constructor that initializes the instance variables using
     * the parameters passed.
     *
     * @param customer
     * @param accountNumber
     */
    public Account(Customer customer, long accountNumber) {
        this.customer = customer;
        this.accountNumber = accountNumber;
        this.balance = 0.00;
        this.transactions = new ArrayList<Transaction>();
    }

    /**
     * The getter method that returns the account number.
     *
     * @return accountNumber
     */
    public long getAccountNumber() {
        return accountNumber;
    }

    /**
     * The getter method that returns the balance of an account.
     *
     * @return balance
     */
    public double getBalance() {
        return balance;
    }

    /**
     * The getter method that returns the Customer object associated with this
     * account.
     *
     * @return customer
     */
    public Customer getCustomer() {
        return customer;
    }

    /**
     * This getter method returns all the transactions made by an account as an
     * ArrayList.
     *
     * @return transactions
     */
    public ArrayList<Transaction> getTransactions() {
        return transactions;
    }

    /**
     * This is a setter method
     *
     * @param accountNumber
     */
    public void setAccountNumber(long accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * This is a setter method
     *
     * @param balance
     */
    public void setBalance(double balance) {
        this.balance = balance;
    }

    /**
     * This is a setter method
     *
     * @param customer
     */
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    /**
     * This is a setter method
     *
     * @param transaactions
     */
    public void setTransactions(ArrayList<Transaction> transaactions) {
        this.transactions = transactions;
    }

    /**
     * This method generates the statement for an account in a specified format.
     *
     * @return toString
     */
    public String generateStatement() {
        return toString();
    }

    /**
     * The abstract method takes a Transaction as a parameter to perform
     * necessary action depending on the type of transaction.
     *
     * @param transaction
     * @throws Exception
     */
    @Override
    public abstract double makeTransaction(Transaction transaction) throws Exception;

    /**
     * This overriding method returns the details of an account.
     *
     * @return toString
     */
    @Override
    public String toString() {
        return customer.toString() + "\nAccount Number: " + accountNumber;
    }

}
