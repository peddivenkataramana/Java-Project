/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accounts;

import enums.TransactionType;
import java.time.LocalDateTime;

/**
 * This class contains the details of a transaction made on an account.
 *
 * @author Venkataramana Peddi
 */
public class Transaction {

    /**
     * Attribute that stores the amount for a transaction
     */
    public double amount;

    /**
     * Attribute that stores the time and date of this transaction as
     * LocalDateTime.
     */
    public LocalDateTime transactonTime;

    /**
     * Status of the transaction i.e whether "SUCCESS" or "FAILED"
     */
    public String status;

    /**
     * Attribute that stores any additional charges involved in the
     */
    public double additionalCharges;

    /**
     * Attribute that stores type of transaction as a TransactionType enum.
     */
    public TransactionType transactionType;

    /**
     * The three argument constructor that initializes the instance variables
     * except status and additional charges.
     *
     * @param transactionType
     * @param amount
     * @param transactonTime
     */
    public Transaction(TransactionType transactionType, double amount, LocalDateTime transactonTime) {
        this.amount = amount;
        this.transactonTime = transactonTime;
        this.transactionType = transactionType;
    }

    /**
     * The setter method that sets the value of instance variable status with
     * passed parameter.
     *
     * @param status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Setter method that sets the any additional charges involved in the
     * transaction
     *
     * @param additionalCharges
     */
    public void setAdditionalCharges(double additionalCharges) {
        this.additionalCharges = additionalCharges;
    }

    /**
     * The getter method that returns the amount of a transaction.
     *
     * @return amount
     */
    public double getAmount() {
        return amount;
    }

    /**
     * The getter method that returns the timestamp of a transaction.
     *
     * @return transactonTime
     */
    public LocalDateTime getTrannsactonTime() {
        return transactonTime;
    }

    /**
     * The getter method that returns the status of a transaction.
     *
     * @return status
     */
    public String getStatus() {
        return status;
    }

    /**
     * The getter method that returns any additional charges added to the
     * transaction
     *
     * @return additionalCharges
     */
    public double getAdditionalCharges() {
        return additionalCharges;
    }

    /**
     * The getter method that returns the type of transaction as TransactionType
     * enum.
     *
     * @return transactionType
     */
    public TransactionType getTransactionType() {
        return transactionType;
    }

    /**
     * This method returns the transaction details concatenated together in a
     * pattern.
     *
     * @return toString
     */
    @Override
    public String toString() {
        if (transactionType == TransactionType.DEPOSIT) {
            return transactionType + "\t\t\t\t" + transactonTime + "\t\t$" + String.format("%.2f", amount) + "\t\t" + "\n" + "$" + String.format("%.2f", additionalCharges) + "\t\t" + status;
        } else {
            return transactionType + "\t\t\t" + transactonTime + "\t\t$" + String.format("%.2f", amount) + "\t\t" + "\n" + "$" + String.format("%.2f", additionalCharges) + "\t\t" + status;
        }

    }

}
