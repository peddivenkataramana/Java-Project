/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accounts;

import enums.TransactionType;
import exceptions.OverdraftLimitExceededException;
import interfaces.Operations;

/**
 * This class extends the Account class implementing all the abstract method.
 * This class is built on the below provided definition of current account. A
 * checking account is a type of bank account that is designed for everyday
 * money transactions. A checking account does not have any withdrawal
 * restrictions, but no interest is earned. It also provides features like
 * overdraft with no additional fees.
 *
 * @author Venkataramana Peddi
 */
public class CurrentAccount extends Account {

    /**
     * A two argument constructor that initializes the instance variables using
     * the arguments passed.
     *
     * @param customer
     * @param accountNumber
     */
    public CurrentAccount(Customer customer, long accountNumber) {
        super(customer, accountNumber);
    }

    /**
     * This method takes transaction object as parameter and performs necessary
     * action, based on the transaction type.
     *
     * @param transaction
     * @return makeTransaction
     * @throws OverdraftLimitExceededException
     */
    @Override
    public double makeTransaction(Transaction transaction) throws OverdraftLimitExceededException {
        double a = 0.0;
        double b = super.getBalance() + Operations.OVERDRAFT_LIMIT;
        if (b >= transaction.getAmount()) {
            if (transaction.getTransactionType() == TransactionType.DEPOSIT) {
                transaction.setAdditionalCharges(0.0);
                transaction.setStatus("SUCCESS");
                a = super.getBalance() + transaction.getAmount();
                transactions.add(transaction);
            } else if (transaction.getTransactionType() == TransactionType.ONLINEPURCHASE) {
                transaction.setAdditionalCharges(1.59);
                transaction.setStatus("SUCCESS");
                a = super.getBalance() - (transaction.getAmount() + transaction.getAdditionalCharges());
                transactions.add(transaction);
            } else {
                transaction.setAdditionalCharges(0.0);
                transaction.setStatus("SUCCESS");
                a = super.getBalance() - transaction.getAmount();
                transactions.add(transaction);
            }
        } else {
            if (transaction.getTransactionType() == TransactionType.DEPOSIT) {
                transaction.setAdditionalCharges(0.0);
                transaction.setStatus("SUCCESS");
                a = super.getBalance() + transaction.getAmount();
                transactions.add(transaction);
            } else {
                transaction.setAdditionalCharges(0.0);
                transaction.setStatus("FAILED");
                a = super.getBalance();
                transactions.add(transaction);
                throw new OverdraftLimitExceededException();
            }
        }
        super.setBalance(a);
        return a;
    }

    /**
     * This method generates the statement for an account in a specified format.
     *
     * @return statement
     */
    @Override
    public String generateStatement() {
        String c = "\n-------------------------------------------------------------------------------\n";
        String d = "";
        for (Transaction e : super.getTransactions()) {
            d += e.toString() + "\n";
        }
        //String transactionss = transationsss.substring(0, transationsss.length() - 1);
        double e;
        if (super.getBalance() < 0) {
            e = 0;
        } else {
            e = super.getBalance();
        }
        return toString() + c + "Transaction Type\t\tTransaction Time\t\tAmount\t\tAdditional \nCharges\t\tStatus\n" + d.substring(0, d.length() - 1) + c + "Current Balance: " + String.format("%.2f", e) + "\nOverdraft usage: $" + String.format("%.2f", (Operations.OVERDRAFT_LIMIT - overDraft())) + "\t\tOverdraft available: $" + String.format("%.2f", overDraft());

    }

    /**
     * This overriding method returns the details of an account.
     *
     * @return toString
     */
    @Override
    public String toString() {
        return (this.customer.toString() + "\nAccount Number: " + this.accountNumber
                + "\nAccount Type: Current Account\t" + "Overdraft Limit: $500.00");
    }

    /**
     * This is a overDraft method
     *
     * @return overdraft
     */
    private double overDraft() {
        if (super.getBalance() < 0) {
            return super.getBalance() + Operations.OVERDRAFT_LIMIT;
        } else {
            return Operations.OVERDRAFT_LIMIT;
        }
    }
}
