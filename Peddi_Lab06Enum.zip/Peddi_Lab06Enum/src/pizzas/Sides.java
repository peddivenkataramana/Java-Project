/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;

/**
 * Class: 44542-05 Object Oriented Programming
 * @author Venkataramana Peddi
 * Description: This is enum sides
 * Due: 10/16/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public enum Sides {
    
 GARLIC_CHEESEBREAD(5.99, 20.99, 30.99), CHEFSALAD(3.99, 15.99, 25.99),
    RANCH_STIX(2.99, 6.99, 13.99), RANCH_POTATO_WEDGES(3.99, 11.99, 22.99),
    MASHED_POTATOES(6.99, 15.99, 30.99), RANCH_CHIPS(4.99, 16.99, 35.99),
    PARMESAN_BROCCOLI(3.99, 8.99, 20.99), ONION_RINGS(1.99, 5.49, 19.49),
    NO_SIDES(0.00, 0.00, 0.00);

    private double smallSidesPrice;
    private double familySidesPrice;
    private double partySidesPrice;
/**
 * This is a parameterized constructor 
 * @param smallSidesPrice
 * @param familySidesPrice
 * @param partySidesPrice 
 */
    private Sides(double smallSidesPrice, double familySidesPrice, double partySidesPrice) {
        this.smallSidesPrice = smallSidesPrice;
        this.familySidesPrice = familySidesPrice;
        this.partySidesPrice = partySidesPrice;
    }
/**
 * This is a getSmallSidesPrice method
 * @return smallSidesPrice
 */
    public double getSmallSidesPrice() {
        return smallSidesPrice;
    }
/**
 * This is a getFamilySidesPrice method
 * @return smallSidesPrice
 */
    public double getFamilySidesPrice() {
        return familySidesPrice;
    }
/**
 * This is a getPartySidesPrice method 
 * @return smallSidesPrice
 */
    public double getPartySidesPrice() {
        return partySidesPrice;
    }
    
    /**
     * This is enum Cheese
     */
    public enum Cheese{
        AMERICAN_CHEESE(0.10), CHEDDAR_CHEESE(0.12), CHEDDAR_JACK_CHEESE(0.20),
        PEPPER_JACK_CHEESE(0.30), QUESO_CHEESE(0.15), SWISS_CHEESE(0.20),
        BLUE_CHEESE(0.12), RANCH(0.20), NO_CHEESE(0.0);
        
        /**
         * This is a getCheesePrice method
         * @return CheesePrice
         */
        public double getCheesePrice() {
            return CheesePrice;
        }

        public double CheesePrice;
/**
 * This is a constructor
 * @param CheesePrice 
 */
        private Cheese(double CheesePrice) {
            this.CheesePrice = CheesePrice;
        }
    }
    
    
    
    
}
