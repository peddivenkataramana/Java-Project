/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;

/**
 *
 * @author S554220
 */
 
    
import pizzas.Days;
import pizzas.Desserts;
import pizzas.Drinks;
import pizzas.PizzaTypes;
import pizzas.Sauces;
import pizzas.Sides;
import pizzas.Sides.Cheese;

/**
 * Class: 44542-05 Object Oriented Programming
 * @author Venkataramana Peddi
 * Description: This is class order
 * Due: 10/16/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
 
public class Order {
    
       
 private PizzaTypes pizzasName;
    private String pizzasSize;
    private int quantity;
    private Sauces sauce;
    private Sides side;
    private String sideSize;
    private Drinks drink;
    private Cheese cheese;
    private Desserts dessert;
    private Double cost;
    /**
     * This is a parameterized constructor
     * @param pizzasName
     * @param pizzasSize
     * @param quantity
     * @param sauce
     * @param side
     * @param sideSize
     * @param drink
     * @param cheese
     * @param dessert 
     */
    public Order(PizzaTypes pizzasName, String pizzasSize, int quantity,
            Sauces sauce, Sides side, String sideSize, Drinks drink, Cheese cheese,
            Desserts dessert) {
        this.pizzasName = pizzasName;
        this.pizzasSize = pizzasSize;
        this.quantity = quantity;
        this.sauce = sauce;
        this.side = side;
        this.sideSize = sideSize;
        this.drink = drink;
        this.cheese = cheese;
        this.dessert = dessert;
    }
    /**
     * This is a getPizzasName method
     * @return pizzasName
     */
    public PizzaTypes getPizzasName() {
        return pizzasName;
    }
    /**
     * This is a getPizzasSize method
     * @return pizzasSize
     */
    public String getPizzasSize() {
        return pizzasSize;
    }
    /**
     * This is a getQuantity method
     * @return quantity
     */
    public int getQuantity() {
        return quantity;
    }
    /**
     * This is a getSauce method
     * @return sauce
     */
    public Sauces getSauce() {
        return sauce;
    }
    /**
     * This is a getSide method
     * @return side
     */
    public Sides getSide() {
        return side;
    }
    /**
     * This is a getSideSize method
     * @return sideSize
     */
    public String getSideSize() {
        return sideSize;
    }
    /**
     * This is a getDrink method
     * @return drink
     */
    public Drinks getDrink() {
        return drink;
    }
    /**
     * This is a getCheese method
     * @return cheese
     */
    public Cheese getCheese() {
        return cheese;
    }
    /**
     * This is a getDessert method 
     * @return dessert
     */
    public Desserts getDessert() {
        return dessert;
    }
     /**
     * This is a getCost method 
     * @return cost
     */
    public Double getCost() {
        return cost;
    }
    /**
     * This is a calcDessertCost method 
     * @return dessert cost
     */
    private double calcDessertCost() {
        return dessert.getDessertPrice();
    }
    /**
     * This is a calcSauceCost method 
     * @return sauce cost
     */
    private double calcSauceCost() {
        return sauce.getPriceOfSauce();
    }
    /**
     * This is a calcCheeseCost method 
     * @return cheese cost
     */
    private double calcCheeseCost() {
        return cheese.getCheesePrice();
    }
    /**
     * This is a calcDrinkCost method
     * @return drink cost
     */
    private double calcDrinkCost() {
        return drink.getDrinkPrice();
    }
    /**
     * This is a calcSideCost method
     * @return sides cost
     */
     private double calcSideCost() {
        if (sideSize.toLowerCase().equals("small")) {
            
                return side.getSmallSidesPrice();}
        else if (sideSize.toLowerCase().equals("medium")){
                return side.getFamilySidesPrice();}
         else  {
                return side.getPartySidesPrice();
        }}
     /**
     * This is a calcPizzasCost method
     * @return pizza cost
     */   
    
    public double calcPizzasCost() {
      
         if(pizzasSize.toUpperCase().equals("SMALL"))   {
                return pizzasName.getSmallPizzaPrice() * quantity;}
         else  if(pizzasSize.toUpperCase().equals("MEDIUM")) {
                return pizzasName.getMediumPizzaPrice() * quantity;}
         else{
                return pizzasName.getLargePizzaPrice() * quantity;
        }
}/**
     * This is a calcDiscount
     * @return discount 
     */
    public double calcDiscount(String orderDate) {
        if (Days.isDiscountDay(orderDate)) {
            if (pizzasName.name().equals("HANDTOSSED_PIZZA")) {
                return calcPizzasCost()/ 2;
            }}
        return 0.0;
    }
    /**
     * This is a getTotalCost
     * @return total cost
     */
    public double getTotalCost(String orderDate) {
        cost = calcDessertCost() + calcSauceCost()+calcDrinkCost()+calcSideCost()+
                + calcCheeseCost() + calcPizzasCost();  
        return cost;
    }
    @Override
   /**
    * This is a to string method 
    */
    
    public String toString() {
        return "PIZZA TYPE: " + pizzasName.toString().replace("_", " ") + "\n"
                + "PIZZA SIZE: " + pizzasSize.toUpperCase() + "\n"
                + "QUANTITY: " + quantity + "\n"
                + "SAUCE: " + sauce.toString().replace("_", " ") + "\n"
                + "SIDES: " + side.toString().replace("_", " ") + " (" + sideSize.toUpperCase() + ")\n"
                + "CHEESE: "+cheese.toString().replace("_", " ")+"\n"
                + "DRINKS: " + drink.toString().replace("_", " ") + "\n"
                + "DESSERTS: " + dessert.toString().replace("_", " ") + "\n"
                + "COST: " + (String.format("%.2f", (Math.round(getCost() * 100)/100.0))) + "\n";
    }
}
