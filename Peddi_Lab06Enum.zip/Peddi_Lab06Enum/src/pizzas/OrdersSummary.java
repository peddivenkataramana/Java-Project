/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;

import java.util.ArrayList;
/**
 * Class: 44542-05 Object Oriented Programming
 * @author Venkataramana Peddi
 * Description: This is class OrdersSummary
 * Due: 10/16/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class OrdersSummary {
  
    private ArrayList<Order> orders = new ArrayList<>();
/**
 * This is a constructor
 */    
 public OrdersSummary() {
    }
 /**
  * This is a getOrders method 
  * @return orders
  */
 public ArrayList<Order> getOrders() {
        return orders;
    }
 /**
  * This is a addAOrder method 
  * @param or 
  */
 public void addAOrder(Order or) {
        orders.add(or);
    }
 /**
  * This is a calcTotalCostOfAllOrders method
  * @param orderDate
  * @return orderCost
  */
    public double calcTotalCostOfAllOrders(String orderDate) {
        double orderCost = 0.0;
        for (Order r : orders) {
            orderCost += r.getTotalCost(orderDate);
        }
        return orderCost;
    }
/**
 * This is a calcTotalBillWithTax method 
 * @param orderDate
 * @return total amount with tax
 */
    public double calcTotalBillWithTax(String orderDate) {
        double orderCost = 0.0;
        for (Order r : orders) {
            orderCost += r.getTotalCost(orderDate) - r.calcDiscount(orderDate);
        }
        return orderCost + (orderCost * (8.6 / 100));
    }
/**
 * This is a printReceipt method
 * @param orderDate
 * @return printReceipt
 */
    public String printReceipt(String orderDate) {
        String printReceipt = "**************  " + orderDate + ", " + Days.getOrderDayOfWeek(orderDate) + "  ***************\n";
        double of = 0.0;
        double tx = 0.0;
        for (Order r : orders) {
            of += r.calcDiscount(orderDate);
            tx += (r.getTotalCost(orderDate) - of) * (8.6 / 100);
            printReceipt += r.toString();
        }
        printReceipt += "-----------------------------------------------------\n"
                + "		Order Total :		$"
                + (String.format("%.2f", (Math.round(calcTotalCostOfAllOrders(orderDate) * 100) / 100.0))) + "\n"
                + "		Discount@50 :		"
                + "$" + (String.format("%.2f", (Math.round(of * 100) / 100.0))) + "\n"
                + "		Tax@8.6 :		"
                + "$" + (String.format("%.2f", (Math.round(tx * 100) / 100.0))) + "\n"
                + "		Total Amount with tx : $"
                + (String.format("%.2f", (Math.round(calcTotalBillWithTax(orderDate) * 100) / 100.0))) + "\n"
                + "-----------------------------------------------------";

        return printReceipt;
    
}}
