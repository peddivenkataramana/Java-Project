/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;

/**
 * Class: 44542-05 Object Oriented Programming
 * @author Venkataramana Peddi
 * Description: This is enum PizzaTypes
 * Due: 10/16/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
 

public enum PizzaTypes {
    
    
    HANDTOSSED_PIZZA(8.50,11.50,14.50), PAN_PIZZA(6.50,9.50,12.50);
    private double smallPizzaPrice;
    private double mediumPizzaPrice;
    private double largePizzaPrice;
    /**
     * This is a parameterized constructor 
    * @param smallPizzaPrice
     * @param mediumPizzaPrice
     * @param largePizzaPrice 
     */
     private PizzaTypes(double smallPizzaPrice, double mediumPizzaPrice, double largePizzaPrice) {
        this.smallPizzaPrice = smallPizzaPrice;
        this.mediumPizzaPrice = mediumPizzaPrice;
        this.largePizzaPrice = largePizzaPrice;
    }
/**
 * This is getSmallPizzaPrice method  
 * @return smallPizzaPrice
 */
    public double getSmallPizzaPrice() {
        return smallPizzaPrice;
    }
/**
 * This is getMediumPizzaPrice method
 * @return mediumPizzaPrice
 */
    public double getMediumPizzaPrice() {
        return mediumPizzaPrice;
    }
/**
 * This is getLargePizzaPrice method
 * @return largePizzaPrice
 */
    public double getLargePizzaPrice() {
        return largePizzaPrice;
    }

}
