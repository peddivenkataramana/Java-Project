/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Class: 44542-05 Object Oriented Programming
 * @author Venkataramana Peddi
 * Description: This is class days
 * Due: 10/16/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class Days {
  /**
   * This is a default constructor
   */  
 private Days() {
    }
/**
 * This is a getOrderDayOfWeek method
 * @param orderDate
 * @return  transactionTime.getDayOfWeek()
 */
    static String getOrderDayOfWeek(String orderDate) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        LocalDate transactionTime = LocalDate.parse(orderDate, formatter);
        return transactionTime.getDayOfWeek().toString();
    }
/**
 * This is a isDiscountDay method
 * @param orderDate
 * @return Discounted day
 */
    static boolean isDiscountDay(String orderDate) {
        return "SATURDAY".equals(getOrderDayOfWeek(orderDate))
                || "SUNDAY".equals(getOrderDayOfWeek(orderDate));
    }
    
}

    
    
    
    
    

