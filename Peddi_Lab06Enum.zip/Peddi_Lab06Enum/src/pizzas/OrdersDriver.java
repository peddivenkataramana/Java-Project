/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;

import java.io.File;
import java.io.FileNotFoundException;
import java.time.DayOfWeek;
import java.util.Scanner;
import pizzas.Sides.Cheese;

/**
 * Class: 44542-05 Object Oriented Programming
 * @author Venkataramana Peddi
 * Description: This is class OrdersDriver
 * Due: 10/16/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class OrdersDriver {
   public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("input.txt"));
        System.out.println("*****************************************************");
        System.out.println("*********************** Pizza Hut ******************");
        System.out.println("*****************************************************");
        while (sc.hasNext()) {

            OrdersSummary o = new OrdersSummary();

            String t = sc.nextLine();

            String w = Days.getOrderDayOfWeek(t);

            String pizzaType = sc.next();
            String p = sc.next();
            sc.nextLine();
            PizzaTypes pizzaTypeEnum = PizzaTypes.valueOf(pizzaType.toUpperCase() + "_" + p.toUpperCase());

            String z = sc.next();
            int y = sc.nextInt();
            sc.nextLine();

            String sue = sc.nextLine();

            String[] sueArray = sue.split(" ");
            sue = "";
            for (String str : sueArray) {
                sue = sue + str + " ";

            }
            sue = sue.trim();
            sue = sue.replaceAll(" ", "_");

            String si = sc.nextLine();

            String[] s = si.split("-");

            String[] siA = s[0].split(" ");
            String newSide = "";
            for (String str : siA) {
                newSide = newSide + str + " ";

            }
            newSide = newSide.trim();
            newSide = newSide.replaceAll(" ", "_");

            String ss = s[1].trim();

            String che = sc.nextLine();

            String[] ch = che.split(" ");

            che = "";

            for (String str : ch) {
                che = che + str + " ";

            }
            che = che.trim();
            che = che.replaceAll(" ", "_");

            String k = sc.nextLine();

            String[] ksArray = k.split(" ");

            k = "";
            for (String str : ksArray) {
                k = k + str + " ";

            }
            k = k.trim();
            k = k.replaceAll(" ", "_");

            String dts = sc.nextLine();
            String[] d = dts.split(" ");

            dts = "";
            for (String str : d) {
                dts = dts + str + " ";

            }
            dts = dts.trim();
            dts = dts.replaceAll(" ", "_");

            Sauces se = Sauces.valueOf(sue.toUpperCase());
            Sides sei = Sides.valueOf(newSide.toUpperCase());

            Cheese chees = Cheese.valueOf(che.toUpperCase());
            Drinks kem = Drinks.valueOf(k.toUpperCase());

            Desserts dse = Desserts.valueOf(dts.toUpperCase());

            Order or = new Order(pizzaTypeEnum, z, y, se, sei, ss, kem, chees, dse);

            o.addAOrder(or);

            System.out.println(o.printReceipt(t));
        }

    }

}
        
        
        
        
        
        
        
        
    
