/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;

/**
 * Class: 44542-05 Object Oriented Programming
 * @author Venkataramana Peddi
 * Description: This is enum Sauces
 * Due: 10/16/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
 
public enum Sauces {
    
  PESTO(0.10),TOMATO(0.12),BECHAMEL(0.20),BBQ(0.30),HUMMUS(0.15),MARINARA(0.20),TAPENADE(0.12),PUMPKIN_PIZZA_SAUCE(0.20),NO_SAUCE(0.00);
    private double priceOfSauce;
  /**
   * This is constructor
   * @param priceOfSauce 
   */  
    private Sauces (double priceOfSauce){
        this.priceOfSauce =priceOfSauce;
    }
/**
 * This is a getPriceOfSauce method
 * @return priceOfSauce
 */
    public double getPriceOfSauce() {
        return priceOfSauce;
    }
    
    
    
    
    
    
    
    
    
    
    
    
}
