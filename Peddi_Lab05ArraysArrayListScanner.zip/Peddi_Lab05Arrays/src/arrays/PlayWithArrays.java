/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrays;

import java.util.Scanner;
import java.util.Arrays;

/**
 * This Play with Array class
 * @author s554220
 */
public class PlayWithArrays {
    public static void main(String[] args) {
        
        String[] moviesA = new  String[5];
        
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Enter the movies array elements : "); 

       
        for(int i=0; i<moviesA.length-1; i++)  
            {  
        moviesA [i] = sc.nextLine();
        
}     
       
        System.out.println("Enter the double array elements : ");
        
        double [] doubleA = new double[6];
        for(int i=0; i<doubleA.length-1 ; i++)  
            {  
        doubleA [i] = sc.nextDouble();
            }
        
        
        System.out.println("Enter the integer array elements : ");
        
        int [] intA = new int[7];
        
         for(int i=0; i<intA.length-1 ; i++)  
            {  
        intA [i] = sc.nextInt();
            }
         
         
         System.out.println("*****************TRAVERSE********************");
         
         
         System.out.println(Arrays.toString(moviesA));
        
        
        System.out.println(Arrays.toString(doubleA));
        
        
        System.out.println(Arrays.toString(intA));
        
         System.out.println("Array movies before insertion : ");
        for(int i=0; i<moviesA.length ; i++)  
            {  
                System.out.print( moviesA [i]+" ");
            } 
        System.out.println("");
        System.out.println("Array double elements before insertion : ");
         for(int i=0; i<doubleA.length ; i++)  
            {  
                System.out.print( doubleA [i]+" ");
            }
         System.out.println("");
         System.out.println("Array integer elements before insertion : ");
         for(int i=0; i<intA.length ; i++)  
            {  
                System.out.print( intA [i]+" ");
            }
    
         System.out.println("");
        System.out.println("*****************INSERTION********************");
        
        System.out.println("movies array elements after insertion:");
        int n1 = moviesA.length;  
int ix = 2;  

String newArr[] = new String[n1];  
int j = 0;  
        
for(int i = 0; i<newArr.length; i++) {  
if(i==ix) {  
newArr[i] = "Avengers";  
}else {  
newArr[i] = moviesA[j];  
j++;  
}  
}  
newArr[ix] = "Avengers";  
for(int i = 0; i<newArr.length; i++) {  
System.out.print(newArr[i]+" ");  
        
}
     
      
        System.out.println("");
        
        
        
        System.out.println("doubleArray elements after insertion:");
        
        int n = doubleA.length;  
int ix1 = 2;  

double newArr1[] = new double[n];  
int j1 = 0;  
  
for(int i = 0; i<newArr1.length; i++) {  
if(i==ix1) {  
newArr1[i] = 20.89;  
}else {  
newArr1[i] = doubleA[j1];  
j1++;  
}  
}  
newArr1[ix1] = 20.89;  
  
for(int i = 0; i<newArr1.length; i++) {  
System.out.print(newArr1[i]+" ");  
        
}
     
      
         System.out.println("");
         
                    System.out.println("intArray elements after insertion:");

        int n11 = intA.length;  
int ix11 = 2;  

int newArr11[] = new int[n11];  
int j11 = 0;  
  
for(int i = 0; i<newArr11.length; i++) {  
if(i==ix11) {  
newArr11[i] = 369;  
}else {  
newArr11[i] = intA[j11];  
j11++;  
}  
}  
newArr11[ix11] = 369;  
  
for(int i = 0; i<newArr11.length; i++) {  
System.out.print(newArr11[i]+" ");  
        
       
}
       
          System.out.println("");
         
        System.out.println("*****************DELETION********************");     
        
        System.out.println("Array movies elements after deleting:");
          
       
       newArr = rem(newArr, 1);
        for(int i = 0; i<newArr.length; i++) {  
System.out.print(newArr[i]+" ");  
        
       
}
        
        
         System.out.println("");
         System.out.println("doubleArray elements after deleting:");
         
          newArr1 = rem(newArr1, 1);
        for(int i = 0; i<newArr1.length; i++) {  
System.out.print(newArr1[i]+" ");  
        
       
}
 
        
        System.out.println("");
         System.out.println("intArray elements after deleting:");
          newArr11 = rem(newArr11, 1);
       for(int i = 0; i<newArr11.length; i++) {  
System.out.print(newArr11[i]+" ");  
       }
         System.out.println("");
        
         
         
           System.out.println("*****************SEARCH********************");
         
         
         
          System.out.println("Element Avengers Found at ix "+ ix(newArr,"Avengers")+" of movies");
         
         
          System.out.println("Element 20.89 Found at ix "+ f1(newArr1,20.89)+" of doubleArray");
         
         
           System.out.println("Element 369 Found at ix "+ f12(newArr11,369)+" of intArray");
         
       
           System.out.println("*****************UPDATE********************");
         
           
           System.out.println("movies after updating: ");
           
             for(int i1 = 0; i1<newArr.length; i1++) {  
                 
                 if(newArr[i1].equals("Avengers"))
                 {
                     newArr[ix(newArr,"Avengers")]="WonderWoman";
                 }
                 System.out.print(newArr[i1]+" ");
             }
                 System.out.println();
  System.out.println("doubleArray elements after updating: ");
        
        
        
             for(int i1 = 0; i1<newArr1.length; i1++) {  
                 
                 if(newArr1[i1]== 20.89)
                 {
                     newArr1[f1(newArr1,20.89)]=67.45;
                 }
                 System.out.print(newArr1[i1]+" ");
   
}System.out.println();
        System.out.println("intArray elements after updating: ");
        
        
             for(int i11 = 0; i11<newArr11.length; i11++) {  
                 
                 if(newArr11[i11]== 369)
                 {
                     newArr11[f12(newArr11,369)]=729;
                      
                 }
                System.out.print(newArr11[i11]+" ");
   
}
        System.out.println("");
        
        
        
         

    
}
 /**
  * This is rem String method 
  * @param newArr
  * @param ix
  * @return result
  */
    
   public static String[] rem(String[] newArr, int ix) {
        String[] result = new String[newArr.length - 1];
        System.arraycopy(newArr, 0, result, 0, ix);
        if (newArr.length != ix) {
            System.arraycopy(newArr, ix + 1, result, ix, newArr.length - ix - 1);
        }
        return result;
    }
   /**
    * This is rem Double method 
    * @param newArr1
    * @param ix
    * @return result
    */
   public static double[] rem(double[] newArr1, int ix) {
        double[] result = new double[newArr1.length - 1];
        System.arraycopy(newArr1, 0, result, 0, ix);
        if (newArr1.length != ix) {
            System.arraycopy(newArr1, ix + 1, result, ix, newArr1.length - ix - 1);
        }
        return result;
        
   }
   /**
    * This is rem int method 
    * @param newArr11
    * @param ix
    * @return result
    */
         public static int[] rem(int[] newArr11, int ix) {
        int[] result = new int[newArr11.length - 1];
        System.arraycopy(newArr11, 0, result, 0, ix);
        if (newArr11.length != ix) {
            System.arraycopy(newArr11, ix + 1, result, ix, newArr11.length - ix - 1);
        }
        return result;
        
         }
        
     /**
      * This is a finding index method for String
      * @param arr1
      * @param t
      */   
        public static int ix(String arr1[], String t)
    {
  
        int ix = Arrays.binarySearch(arr1, t);
        return (ix < 0) ? -1 : ix;
    }
    /**
     * This is a finding index method for Double
     * @param arr
     * @param t
     * @param start
     * 
     */
       public static int ix1(double arr[], double t, int start)
    {
          if(start==arr.length)
            return -1;
           if(arr[start]==t)
            return start;
            return ix1(arr,t,start+1);
    } 
         public static int f1(double arr[], double t)
    {
        return ix1(arr,t,0);
    }
   /**
    * This is a finding index method method for Int 
    * @param arr
    * @param t
    * @param start
    *  
    */
        public static int ix(int arr[], int t, int start)
    {
          if(start==arr.length)
            return -1;
           if(arr[start]==t)
            return start;
            return ix(arr,t,start+1);
    }
         public static int f12(int arr[], int t)
    {
        return ix(arr,t,0);
    }
   
        
        
    }
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
