/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrays;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * This is a PlaywithArrayLists class
 * @author s554220
 */
public class PlayWithArrayLists {
    
    
    
    
    public static void main(String[] args) {
        
        
        
          ArrayList<String> moviesAL = new ArrayList<String>(4);
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the movie names : ");
           moviesAL.add(sc.nextLine());
           moviesAL.add(sc.nextLine());
           moviesAL.add(sc.nextLine());
           moviesAL.add(sc.nextLine());
       
          System.out.println("Enter the double elements: ");
          
          ArrayList<Double> doubleAL = new ArrayList<Double>(5);
        
        doubleAL.add(sc.nextDouble());
        doubleAL.add(sc.nextDouble());
            doubleAL.add(sc.nextDouble());
             doubleAL.add(sc.nextDouble());
              doubleAL.add(sc.nextDouble());
             
          System.out.println("Enter the integers: ");
          
          ArrayList<Integer> intAL = new ArrayList< >(6);
          
           intAL.add(sc.nextInt());
           intAL.add(sc.nextInt());
           intAL.add(sc.nextInt());
           intAL.add(sc.nextInt());
           intAL.add(sc.nextInt());
           intAL.add(sc.nextInt());
          
          
          
          System.out.println("*****************TRAVERSE********************");
          
          System.out.println(moviesAL.toString());
          
          System.out.println(doubleAL.toString());
          
          System.out.println(intAL.toString());
         /* 
          
          for(int i=0;i<moviesAL.size();i++){
              System.out.print(moviesAL.get(i));
          }
          
          System.out.println();
          
          
          
           for(int i=0;i<moviesAL.size();i++){
              System.out.print(doubleAL.get(i));
          }
          
          System.out.println();
          
          
          
           for(int i=0;i<moviesAL.size();i++){
              System.out.print(intAL.get(i));
          }
          
          System.out.println();
          */
          
          
          System.out.println("*****************INSERTION********************");
          
          moviesAL.add(2, "Avengers");
          
           System.out.println(moviesAL.toString());
          
          
           doubleAL.add(2, 20.89);
          
           System.out.println(doubleAL.toString());
          
            intAL.add(2, 369);
          
           System.out.println(intAL.toString());
          
           
           System.out.println("*****************DELETION********************");
        
           moviesAL.remove(1);
                     System.out.println(moviesAL.toString());

          doubleAL.remove(1);
                  System.out.println(doubleAL.toString());

          intAL.remove(1);
          
                     System.out.println(intAL.toString());

                      
       System.out.println("*****************SEARCH********************"); 
                     
       
             int index1 = moviesAL.indexOf("Avengers");
                  System.out.println("Index of Avengers element in moviesAL is "+index1);
                     
                     
                 int index11 = doubleAL.indexOf(20.89);

  
                  System.out.println("Index of Avengers element in moviesAL is "+index11);
                     
                          
                     int index111 = intAL.indexOf(369);

  
                  System.out.println("Index of Avengers element in moviesAL is "+index111);
                     
                          
               
                  System.out.println(moviesAL.toString());
          
          System.out.println(doubleAL.toString());
          
          System.out.println(intAL.toString());
          
          System.out.println("*****************UPDATION********************");
          
           
                 moviesAL.set(index1, "WonderWoman");
    System.out.println(moviesAL.toString());
                 doubleAL.set(index1,67.45); 
                System.out.println(doubleAL.toString());
            
                  intAL.set(index1,729); 
                  
               System.out.println(intAL.toString());   
                  
                  
                  
                  
                  
                  
                  
                  
                  
                  
                  
                  
          
        
} 
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

