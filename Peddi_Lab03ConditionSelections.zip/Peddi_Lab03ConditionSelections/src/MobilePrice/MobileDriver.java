/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MobilePrice;
import java.util.Scanner;
/**
 * This is a  Driver class to the provider calculator class
 * @author s554220
 */
public class MobileDriver {
    
    
    public static void main(String[] args) {
        int o=0;
        boolean g = true;
        System.out.println("Enter User Details:");
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Select the provider’s name: AT&T, T-Mobile, Verizon: ");
        String p = sc.nextLine();  
        
         System.out.print("How many number of users? ");
        int n = sc.nextInt();
        
        
        System.out.print("Are you a member of the Mobile Alliance? ");
        boolean isMemberOfMobileAlliance = sc.nextBoolean(); 
        
        System.out.print("Are you a first time user? ");
        String isFirstTimeUser = sc.next();
        
        System.out.print("Do you have coupon?");
        String hasCoupon = sc.next();
 
        
        ProviderCalculator c = new ProviderCalculator(p,n,isMemberOfMobileAlliance,isFirstTimeUser,hasCoupon);
       
       
        if (!(c.checkProviderName(c.getProviderName()))) {
            o++;
            g = false;
            System.out.println("Error#" + o + ": The provider’s name " + p + " does not match the providers’list");
        }

        if (c.getNumOfUsers() == 0) {
            o++;
            g = false;
            System.out.println("Error#" + o + ": The  number  of users should not be zero.");
        }

        if (c.getNumOfUsers() > 5) {
            o++;
            g = false;
            System.out.println("Error#" + o + ": the number of users should be between 3 and 5.");

        }
        if(c.getIsMemberOfMobileAlliance() && c.getHasCoupon().equals("Yes")|| (c.getIsMemberOfMobileAlliance() && c.getIsFirstTimeUser().equals("Y")|| c.getHasCoupon().equals("Yes") && c.getIsFirstTimeUser().equals("N"))){
            o++;
            g = false;
            System.out.println("Error#" + o + ": User can only use one discount,(1) Member of the Mobile Alliance,(2)First Time User,or(3)has a coupon at a time.\n You are required to choose only one option:(1),(2),or(3)");
        }

        if (g){

            System.out.println("\n**********\n");
            System.out.println("    User Provider Details:        ");
            System.out.println("Provider: " + c.getProviderName());
            System.out.println("Number of user: " + c.getNumOfUsers());
            System.out.println("Member of the Mobile Alliance: " + c.getIsMemberOfMobileAlliance());
            System.out.println("first time user: " + c.getIsFirstTimeUser());
            System.out.println("have coupon: " + c.getHasCoupon());
            System.out.println("\n *********\n");
            System.out.println("     •  ++++ Receipt ++++");
            System.out.println(c.printReceipt());
    }
            
   
    }
        
       
    
       
  
    }

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

