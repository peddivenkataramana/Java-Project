/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MobilePrice;

/**
 *This is ProviderCalculator class
 * @author s554220
 */
public class ProviderCalculator {
    
  private String providerName;
  private  int    numOfUsers;
  private  Boolean isMemberOfMobileAlliance;
  private  String    isFirstTimeUser;
  private  String hasCoupon;
  private  static final double COUPON = 5.00;
  private  static final double SALETAXES = 7.50;
  boolean r ;
  String t;
  /**
   * This is a constructor
   * @param providerName
   * @param numOfUsers
   * @param isMemberOfMobileAlliance
   * @param isFirstTimeUser
   * @param hasCoupon 
   */
    public ProviderCalculator(String providerName, int numOfUsers, Boolean isMemberOfMobileAlliance, String isFirstTimeUser, String hasCoupon) {
        this.providerName = providerName;
        this.numOfUsers = numOfUsers;
        this.isMemberOfMobileAlliance = isMemberOfMobileAlliance;
        this.isFirstTimeUser = isFirstTimeUser;
        this.hasCoupon = hasCoupon;
    }
    /**
     * This is a getProviderName method
     * @return  providerName
     */
    public String getProviderName() {
        return providerName;
    }
    /**
     * This is a getNumOfUsers method 
     * @return numOfUsers
     */
    public int getNumOfUsers() {
        return numOfUsers;
    }
    /**
     * This is a getIsMemberOfMobileAlliance method
     * @return isMemberOfMobileAlliance
     */
    public Boolean getIsMemberOfMobileAlliance() {
        return isMemberOfMobileAlliance;
    }
    /**
     * This is a getIsFirstTimeUser method 
     * @return isFirstTimeUser
     */
    public String getIsFirstTimeUser() {
        return isFirstTimeUser;
    }
    /**
     * This is a getHasCoupon method 
     * @return hasCoupon
     */
    public String getHasCoupon() {
        return hasCoupon;
    }
    /**
     * This is a getCOUPON method 
     * @return COUPON
     */
    public static double getCOUPON() {
        return COUPON;
    }
    /**
     * This is a getSALETAXES method 
     * @return SALETAXES
     */
    public static double getSALETAXES() {
        return SALETAXES;
    }
    /**
     * This is a  setProviderName method
     * @param providerName 
     */
    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }
    /**
     * This is a setNumOfUsers method 
     * @param numOfUsers 
     */
    public void setNumOfUsers(int numOfUsers) {
        this.numOfUsers = numOfUsers;
    }
    /**
     * This is a setIsMemberOfMobileAlliance method 
     * @param isMemberOfMobileAlliance 
     */
    public void setIsMemberOfMobileAlliance(Boolean isMemberOfMobileAlliance) {
        this.isMemberOfMobileAlliance = isMemberOfMobileAlliance;
    }
    /**
     * This is a  setIsFirstTimeUser method 
     * @param isFirstTimeUser 
     */
    public void setIsFirstTimeUser(String isFirstTimeUser) {
        this.isFirstTimeUser = isFirstTimeUser;
    }
    /**
     * This is a setHasCoupon method 
     * @param hasCoupon 
     */
    public void setHasCoupon(String hasCoupon) {
        this.hasCoupon = hasCoupon;
    }

    /**
     * This is a toString method
     */
    public String toString() {
        return "ProviderCalculator{" + "providerName=" + providerName + ", numOfUsers=" + numOfUsers + ", isMemberOfMobileAlliance=" + isMemberOfMobileAlliance + ", isFirstTimeUser=" + isFirstTimeUser + ", hasCoupon=" + hasCoupon + '}';
    }
   /**
    * This is  a checkProviderName method 
    * @return r 
    */
    public  boolean checkProviderName(String k){
             
        switch(k){
           case "AT&T":
                r = true;
                break;
            case "T-Mobile":
                r = true;
                break;
            case "Verizon":
                r = true;
                break;
            default:
                r = false;
                break;
         }
        return r;
        
    }
    /**
     * This is a calcProviderPrice method 
     * @return price
     */    
    private double calcProviderPrice(){
        
               
        if(getProviderName().equals("AT&T") && getNumOfUsers() == 1){
            return 30.99;
        }
        else if(getProviderName().equals("AT&T") && getNumOfUsers() == 2){
            return 52.99;
        }
        else if(getProviderName().equals("AT&T") && getNumOfUsers() == 3 ||  getNumOfUsers()== 5){
            return 20.99;
        }
        else if(getProviderName().equals("T-Mobile") && getNumOfUsers() == 1){
            return 39.99;
        }
         else if(getProviderName().equals("T-Mobile")&& getNumOfUsers() == 2){
            return 70.99;
        } 
         else if(getProviderName().equals("T-Mobile") &&  getNumOfUsers() == 3 ||  getNumOfUsers()== 5){
            return 29.99;
        }
        else if(getProviderName().equals("Verizon") && getNumOfUsers() == 1){
            return 43.99;
        }
         else if(getProviderName().equals("Verizon")&& getNumOfUsers() == 2){
            return 75.99;
        } else if(getProviderName().equals("Verizon") &&  getNumOfUsers() == 3 || getNumOfUsers()== 5){
            return 33.99;
        }
        else return 0.0;
    }
    /**
     * This is a calcMembershipDiscount method
     * @return membership discount 
     */
        private double calcMembershipDiscount(){
            
        if(isMemberOfMobileAlliance.equals(true) &&numOfUsers == 1){
          
              return  0.075 * calcProviderPrice();
              
          }
          else if(isMemberOfMobileAlliance.equals(true) && numOfUsers == 2){
              return 0.065 * calcProviderPrice();
          }
          else if(isMemberOfMobileAlliance.equals(true) &&numOfUsers == 3 || numOfUsers == 4 || numOfUsers ==5){
              return 0.085 * calcProviderPrice();
          }
          else return 0.0;}
        
    /**
     * This is a calcFirstTimeUserDiscount method
     * @return first time user discount
     */    
    private double calcFirstTimeUserDiscount(){
        
            if(isFirstTimeUser.equals("Yes")&& numOfUsers == 1){
              return  0.1 * calcProviderPrice();
              
            }
            else if(isFirstTimeUser.equals("Yes")&& numOfUsers == 2){
            return  0.05 * calcProviderPrice();
            }
            else if(isFirstTimeUser.equals("Yes")&& numOfUsers == 3 || numOfUsers == 4 || numOfUsers ==5){
              return 0.04* calcProviderPrice();
            }
             
             else  return 0.0;
        }
  
   private double chooseYourDiscount(){
        if (t.equals(isMemberOfMobileAlliance)){
            return calcMembershipDiscount();
            
        }
        else if(t.equals (isFirstTimeUser)){
            return calcFirstTimeUserDiscount();

        }
        else if(t.equals(hasCoupon)){
            return COUPON;
        }
        return 0.0;
     
        } 
    
/**
 * This is  a calcCouponDiscount method 
 * @return coupon discount
 */   
    private double calcCouponDiscount()
    {
        if(hasCoupon.equals("Y"))
        {
           return COUPON;
        }
        else
        {
          return 0.0;
        }     
    }     
    
    /**
     * This is a totalPrice method 
     * @return total price
     */
    private double totalPrice(){
      return calcProviderPrice() -  calcMembershipDiscount() - calcFirstTimeUserDiscount() - calcCouponDiscount();
    }
    /**
     * This is a totalPriceWithSalesTax method
     * @return total price with tax
     */ 
    private double totalPriceWithSalesTax(){
        
             return  (SALETAXES/100) * totalPrice()+ totalPrice();
       
    }
      /**
       * This is a printReceipt method
       * @return receipt
       */
        public String printReceipt(){
         return  "Mobile Charges for "+  getNumOfUsers() +" user using "+getProviderName()+" as provider is: $"+Math.abs(calcProviderPrice()) + "\n"
        +"Member of the Mobile Alliance: $"+Math.round(calcMembershipDiscount()*100.0)/100.0+"\n"
        + "First Time user discount: $"+Math.round(calcFirstTimeUserDiscount()*100.0)/100.0+"\n"
        +"Coupon Discount: $"+Math.round(calcCouponDiscount()*100.0)/100.0+"\n"
        +"Charges After applying Discount: $"+ Math.round(totalPrice()*100.0)/100.0+"\n"
        +"Total Price with Tax: $"+Math.round(totalPriceWithSalesTax()*100.0)/100.0+"\n";
       
        }
    
    }
